# -*- coding: utf-8 -*-
"""Conservative identity, timing persistence and reference-image validation."""
import base64
import hashlib
import json
import re
import sqlite3
import struct
import time

from resources.lib.modules.family_filters import FilterError, number, timestamp


def timing_key(url, identity, data, subtitles=None):
    # Include query and headers: rotating signed URLs cause a safe cache miss.
    # Never store the URL, credentials, headers or release name in the database.
    def revision(item):
        if item is None:
            return None
        return item['metadata'].get('fingerprint') or item
    material = [url, identity, revision(data), revision(subtitles)]
    return hashlib.sha256(json.dumps(material, sort_keys=True, ensure_ascii=True).encode()).hexdigest()


def read_timing(path, key):
    try:
        with sqlite3.connect(path, timeout=1) as db:
            row = db.execute('SELECT scene, subtitle FROM family_timing WHERE key=?', (key,)).fetchone()
        if row:
            return (number(row[0], -3600, 3600), number(row[1], -3600, 3600))
    except (sqlite3.Error, FilterError, TypeError):
        pass
    return None


def save_timing(path, key, scene, subtitle):
    scene, subtitle = number(scene, -3600, 3600), number(subtitle, -3600, 3600)
    try:
        with sqlite3.connect(path, timeout=1) as db:
            db.execute('CREATE TABLE IF NOT EXISTS family_timing '
                       '(key TEXT PRIMARY KEY, scene REAL, subtitle REAL, updated REAL)')
            db.execute('INSERT OR REPLACE INTO family_timing VALUES (?, ?, ?, ?)',
                       (key, scene, subtitle, time.time()))
        return True
    except sqlite3.Error:
        return False


def forget_timing(path, key):
    try:
        with sqlite3.connect(path, timeout=1) as db:
            db.execute('DELETE FROM family_timing WHERE key=?', (key,))
        return True
    except sqlite3.Error:
        return False


def episode_number(value, minimum=0):
    if not re.fullmatch(r'\d{1,4}', str(value)) or int(value) < minimum:
        raise FilterError('A single, explicitly numbered season and episode is required')
    return int(value)


def validate_identity(media_type, imdb, season, episode, metadata, filename='', episode_imdb=''):
    """Reject contradictions; missing identity still requires explicit adult confirmation."""
    kind = metadata.get('type')
    imported_id = re.fullmatch(r'tt\d{7,10}', str(metadata.get('imdb', '')))
    if metadata.get('imdb') and not imported_id:
        raise FilterError('The filter contains an invalid IMDb identity')
    if media_type == 'movie':
        if kind == 'episode' or metadata.get('season') is not None or metadata.get('episode') is not None:
            raise FilterError('An episode filter cannot be used for a movie')
        if imported_id and imdb and imported_id[0] != imdb:
            raise FilterError('This filter belongs to a different IMDb movie')
        return
    if media_type != 'episode' or kind not in (None, 'episode'):
        raise FilterError('The selected filter media type does not match this episode')
    season, episode = episode_number(season), episode_number(episode, 1)
    for key, expected in (('season', season), ('episode', episode)):
        if key in metadata and episode_number(metadata[key]) != expected:
            raise FilterError('This filter belongs to a different season or episode')
    if metadata.get('showimdb') and metadata['showimdb'] != imdb:
        raise FilterError('This filter belongs to a different show')
    if imported_id and (not episode_imdb or imported_id[0] != episode_imdb):
        raise FilterError('The filter IMDb episode ID cannot be matched to this episode; a show ID is not sufficient')
    # Explicit filename numbers are evidence of contradictions, not proof of identity.
    if re.search(r'(?i)S\d{1,3}E\d{1,4}(?:[ ._-]*E\d|[ ._-]+\d{2}\b)', filename):
        raise FilterError('Combined-episode files need a dedicated timeline and are not supported')
    matches = re.findall(r'(?i)S(\d{1,3})E(\d{1,4})', filename)
    if matches and any((int(s), int(e)) != (season, episode) for s, e in matches):
        raise FilterError('The filename identifies a different episode')


def alignment_offset(reference, actual, second_reference=None, second_actual=None):
    offset = number(timestamp(actual) - number(reference), -3600, 3600)
    if second_reference is not None or second_actual is not None:
        other = timestamp(second_reference)
        if abs(other - float(reference)) < 60:
            raise FilterError('Use a second reference at least one minute away, preferably late in the video')
        other_offset = timestamp(second_actual) - other
        if abs(other_offset - offset) > 0.25:
            raise FilterError('The landmarks disagree. A single timing offset cannot be confirmed; choose another release/filter')
    return offset


def reference_image(data_uri):
    """Decode only bounded JPEG/PNG images; never URLs, SVG or executable content."""
    match = re.fullmatch(r'data:image/(jpeg|png);base64,([A-Za-z0-9+/=\r\n]+)', str(data_uri))
    if not match or len(match[2]) > 700000:
        raise FilterError('Unsupported or oversized reference image')
    try:
        raw = base64.b64decode(match[2].replace('\r', '').replace('\n', ''), validate=True)
        if match[1] == 'png':
            if raw[:8] != b'\x89PNG\r\n\x1a\n' or raw[12:16] != b'IHDR':
                raise ValueError()
            width, height = struct.unpack('>II', raw[16:24])
        else:
            if raw[:2] != b'\xff\xd8':
                raise ValueError()
            pos, width, height = 2, 0, 0
            while pos < len(raw):
                if raw[pos] != 255:
                    raise ValueError()
                while pos < len(raw) and raw[pos] == 255:
                    pos += 1
                marker = raw[pos]
                pos += 1
                if marker in (0xD9, 0xDA):
                    break
                length = struct.unpack('>H', raw[pos:pos + 2])[0]
                if length < 2 or pos + length > len(raw):
                    raise ValueError()
                if marker in (0xC0, 0xC1, 0xC2):
                    height, width = struct.unpack('>HH', raw[pos + 3:pos + 7])
                    break
                pos += length
        if not (0 < width <= 4096 and 0 < height <= 4096 and width * height <= 4000000):
            raise ValueError()
    except (ValueError, IndexError, struct.error):
        raise FilterError('Invalid or oversized reference image')
    return raw, 'jpg' if match[1] == 'jpeg' else 'png'
