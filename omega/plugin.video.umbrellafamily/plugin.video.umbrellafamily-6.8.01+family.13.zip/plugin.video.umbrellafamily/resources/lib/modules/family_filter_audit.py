# -*- coding: utf-8 -*-
"""Read-only audit model. No Kodi dependency and no automatic playback actions."""
from resources.lib.modules.family_filters import (FilterError, MAX_STARTUP_PREROLL,
    STARTUP_TIMING_GRACE, compile_timeline, number, rule_action)


def plain(value):
    # Provider descriptions are text, not Kodi formatting or executable labels.
    return ' '.join(str(value).replace('[', '(').replace(']', ')').split())[:500]


def audit_rows(data, thresholds=None, offset=0, padding=0.5, mute=False):
    rows = []
    for original in data['segments']:
        # Timing uses the same implementation as real filtering, but deliberately
        # includes disabled categories. Never describe a negative/invalid range.
        one = compile_timeline({'segments': [original]}, offset=offset, padding=padding, mute=True)
        start, end = one[original['action']][0]
        action = rule_action(original, thresholds, mute)
        threshold = int((thresholds or {}).get(original['category'], 1))
        reason = ('category disabled' if threshold == 0 else 'below selected severity') if action is None else 'selected'
        if action == 'skip' and original['action'] == 'mute':
            reason = 'audio markers set to skip'
        category = original['category']
        if data['source'] == 'VideoSkip import' and category == 'sex':
            category = 'sex/nudity (combined)'
        rows.append(dict(start=start, end=end, action=action, source=plain(data['source']),
                         original_action=original['action'], category=category,
                         severity=original['severity'] or 'unrated', selection=reason,
                         label=plain(original.get('label') or 'No detailed reason supplied')))
    return sorted(rows, key=lambda row: (row['start'], row['end']))


def clock(seconds):
    seconds = int(max(0, seconds))
    return '%02d:%02d:%02d' % (seconds // 3600, seconds // 60 % 60, seconds % 60)


class AuditModel:
    def __init__(self, rows, timeline, mode):
        if mode not in ('current', 'all'):
            raise FilterError('Unknown audit view')
        self.rows, self.timeline, self.mode = rows, timeline, mode
        self.position = 0
        self.started_at = None
        self.duration_ready = False
        self.navigation = None

    def visible_rows(self):
        return [row for row in self.rows if self.mode == 'all' or row['action']]

    def tick(self, position, duration, now):
        if self.started_at is None:
            self.started_at = now
        position = number(position, -MAX_STARTUP_PREROLL)
        duration = number(duration)
        if position < 0 and now - self.started_at >= STARTUP_TIMING_GRACE:
            raise FilterError('Invalid audit playback position after startup')
        if duration == 0:
            if self.duration_ready or now - self.started_at >= STARTUP_TIMING_GRACE:
                raise FilterError('Audit video duration is unavailable')
        else:
            self.duration_ready = True
            if any(row['end'] > duration for row in self.rows):
                raise FilterError('Audit markers extend beyond this video; check timing and edition')
        self.position = max(0, position)

    def effective(self):
        for action in ('skip', 'mute'):
            if any(start <= self.position < end for start, end in self.timeline[action]):
                return action
        return 'allow'

    def active(self):
        return [row for row in self.visible_rows() if row['start'] <= self.position < row['end']]

    def describe(self, row):
        return '%s-%s | %s / %s | %s | marked %s; current: %s (%s) | %s' % (
            clock(row['start']), clock(row['end']), row['category'], row['severity'],
            row['label'], row['original_action'].upper(), (row['action'] or 'allow').upper(), row['selection'], row['source'])

    def banner(self):
        active = self.active()
        outcomes = {'skip': 'would SKIP picture and sound',
                    'mute': 'would MUTE audio and hide subtitles; picture plays',
                    'allow': 'would ALLOW picture, audio and subtitles (user controls unchanged)'}
        lines = ['Current settings: ' + outcomes[self.effective()]]
        if active:
            for row in active[:2]:
                lines.append('%s / %s | %s (%s) | %s' % (
                    row['category'], row['severity'], (row['action'] or 'allow').upper(),
                    row['selection'], row['label'][:100]))
            if len(active) > 2:
                lines.append('+%d overlapping markers; choose Details' % (len(active) - 2))
        else:
            lines.append('No marked interval in this view. This is not a content-safety rating.')
        return '\n'.join(lines)

    def details(self):
        rows = self.active()
        return ('AUDIT: original video/audio play unchanged. Timing and coverage are unverified.\n'
                'Skip takes precedence over mute when selected intervals overlap.\n\n' + self.banner() +
                '\n\n' + '\n'.join(self.describe(row) for row in rows))

    def navigate(self, direction, position):
        """Group overlapping markers; lead in by 3s. Never seek automatically."""
        position = number(position, -MAX_STARTUP_PREROLL)
        spans = []
        for row in sorted(self.visible_rows(), key=lambda item: item['start']):
            if spans and row['start'] <= spans[-1][1]:
                spans[-1] = (spans[-1][0], max(spans[-1][1], row['end']))
            else:
                spans.append((row['start'], row['end']))
        cursor = position
        if self.navigation:
            start, target = self.navigation
            # Repeated clicks during seek/lead-in advance instead of selecting
            # the same marker. Clear on a genuine seek away or forward progress.
            if target - 0.5 <= position < start:
                cursor = start
            else:
                self.navigation = None
        candidates = [span for span in spans if (span[0] > cursor + 0.05 if direction > 0 else span[0] < cursor - 0.05)]
        if not candidates:
            return None
        start = (candidates[0] if direction > 0 else candidates[-1])[0]
        target = max(0, start - 3)
        self.navigation = (start, target)
        return target

    def toggle(self):
        self.mode = 'all' if self.mode == 'current' else 'current'
        self.navigation = None
