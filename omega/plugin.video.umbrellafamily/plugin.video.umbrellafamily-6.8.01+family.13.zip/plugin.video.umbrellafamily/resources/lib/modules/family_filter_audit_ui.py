# -*- coding: utf-8 -*-
"""Explicitly unfiltered parent review overlay; never changes mute/subtitle state."""
import xbmcgui
from resources.lib.modules import control


class AuditOverlay(xbmcgui.WindowXMLDialog):
    def onInit(self):
        self.window_id = xbmcgui.getCurrentWindowDialogId()
        self.ready = True
        self.setFocusId(100)

    def onClick(self, control_id):
        command = {100: 'next', 101: 'previous', 102: 'view', 103: 'pause', 104: 'details', 105: 'stop',
                   106: 'align', 107: 'reference', 108: 'reference_seek', 109: 'back_second',
                   110: 'forward_second', 111: 'mark', 112: 'enable_filters'}.get(control_id)
        if command:
            self.command(command)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (9, 10, 13, 92, 216):
            self.command('stop')
        elif action_id in (12, 229):
            self.command('pause')
        elif action_id == 79:
            self.command('play')


def create_overlay(command):
    from resources.lib.modules.family_filter_playback_ui import OverlayHost
    return OverlayHost(AuditOverlay, 'family_audit.xml', command)
