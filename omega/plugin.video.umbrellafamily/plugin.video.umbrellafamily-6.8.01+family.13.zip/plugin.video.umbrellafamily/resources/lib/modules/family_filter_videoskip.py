# -*- coding: utf-8 -*-
"""On-demand VideoSkip exchange browsing. Fixed origin, bounded HTML, local cache.

Uses the site's public read-only pages, not an assumed JSON API. Never crawls,
uploads, authenticates, follows external redirects, or guesses a title match.
"""
from html.parser import HTMLParser
import re
import sqlite3
import time
from threading import Lock
from urllib.parse import urlencode, urlsplit

from resources.lib.modules.family_filters import FilterError, MAX_BYTES, parse_file

ORIGIN = 'https://videoskip.herokuapp.com'
_lock = Lock()
_last_request = 0


def clean(text):
    return ' '.join(str(text).split()).replace('[', '(').replace(']', ')')[:1500]


class Node:
    def __init__(self, tag='', attrs=None):
        self.tag, self.attrs, self.children = tag, dict(attrs or []), []

    def text(self):
        return clean(' '.join(child.text() if isinstance(child, Node) else child for child in self.children))

    def find(self, tag):
        result = [self] if self.tag == tag else []
        for child in self.children:
            if isinstance(child, Node):
                result.extend(child.find(tag))
        return result


class Page(HTMLParser):
    def __init__(self, body):
        super().__init__(convert_charrefs=True)
        self.root = Node()
        self.stack, self.count = [self.root], 0
        self.feed(body)
        self.close()

    def handle_starttag(self, tag, attrs):
        self.count += 1
        if self.count > 20000 or len(self.stack) > 80:
            raise FilterError('VideoSkip page is too complex')
        node = Node(tag, attrs)
        self.stack[-1].children.append(node)
        if tag not in ('area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'):
            self.stack.append(node)

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                self.stack = self.stack[:index]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def route_id(node, kind):
    match = re.fullmatch(r'/exchange/' + kind + r'/(\d{1,10})/', node.attrs.get('href', ''))
    return match[1] if match else None


def imdb_id(root):
    ids = set()
    for link in root.find('a'):
        parsed = urlsplit(link.attrs.get('href', ''))
        match = re.fullmatch(r'/title/(tt\d{7,10})/?', parsed.path)
        if parsed.scheme == 'https' and parsed.hostname in ('www.imdb.com', 'imdb.com') and match:
            ids.add(match[1])
    if len(ids) != 1:
        raise FilterError('VideoSkip page has no unambiguous IMDb identity')
    return ids.pop()


def parse_search(body, kind):
    root = Page(body).root
    headings = root.find('h1')
    if len(headings) != 1 or not headings[0].text().startswith('Showing results for'):
        raise FilterError('VideoSkip search page changed or is unavailable')
    # Only accept links in the relevant section, never pending requests.
    wanted = 'Series with existing videos' if kind == 'episode' else 'Videos with skip files'
    if wanted not in [node.text() for node in root.find('h3')]:
        raise FilterError('VideoSkip search section is missing or changed')
    section, results, seen = '', [], set()
    def walk(node):
        nonlocal section
        if node.tag == 'h3':
            section = node.text()
        if node.tag == 'a' and section == wanted:
            identifier = route_id(node, 'series' if kind == 'episode' else 'videos')
            title = node.text()
            if identifier and identifier not in seen and (kind == 'episode' or not re.search(r'\bS\d+\s+E\d+:', title)):
                seen.add(identifier)
                results.append({'id': identifier, 'title': title})
        for child in node.children:
            if isinstance(child, Node):
                walk(child)
    walk(root)
    return results[:100]


def parse_title(body):
    root = Page(body).root
    headings = root.find('h1')
    if len(headings) != 1:
        raise FilterError('VideoSkip title page changed')
    heading = headings[0]
    series = [route_id(link, 'series') for link in heading.find('a') if route_id(link, 'series')]
    number = re.search(r'\bS(\d{1,4})\s+E(\d{1,4}):', heading.text())
    if bool(series) != bool(number) or len(series) > 1:
        raise FilterError('VideoSkip episode identity is ambiguous')
    skips = list(dict.fromkeys(route_id(link, 'skip') for link in root.find('a') if route_id(link, 'skip')))
    return dict(title=heading.text(), imdb=imdb_id(root), kind='episode' if series else 'movie',
                series=series[0] if series else None, season=int(number[1]) if number else None,
                episode=int(number[2]) if number else None, skips=skips[:100])


def parse_series(body, imdb, season, episode):
    root = Page(body).root
    if imdb_id(root) != imdb:
        raise FilterError('This VideoSkip series belongs to a different IMDb show')
    matches = []
    for link in root.find('a'):
        identifier = route_id(link, 'videos')
        number = re.match(r'S(\d+)\s+E(\d+):', link.text())
        if identifier and number and (int(number[1]), int(number[2])) == (season, episode):
            matches.append(identifier)
    if len(set(matches)) != 1:
        raise FilterError('No unique entry for this exact episode in VideoSkip')
    return matches[0]


def parse_skip(body, video_id, skip_id):
    root = Page(body).root
    headings = root.find('h1')
    if len(headings) != 1 or {route_id(link, 'videos') for link in headings[0].find('a')} != {video_id}:
        raise FilterError('VideoSkip filter belongs to a different title')
    target = '/exchange/skip/%s/download/' % skip_id
    if not any(form.attrs.get('action') == target and form.attrs.get('method', 'get').lower() == 'get' for form in root.find('form')):
        raise FilterError('VideoSkip download link is missing or changed')
    author = next((node.text() for node in root.find('h4') if node.text().startswith('By ')), 'Author not supplied')
    entries = [node.text() for node in root.find('li')]
    edition = next((text[len('Synced with:'):].strip() for text in entries if text.startswith('Synced with:')), 'Not supplied')
    notes = next((node.text() for node in root.find('p') if 'pre-wrap' in node.attrs.get('style', '')), '')
    return dict(author=author, edition=edition, description=notes, path=target)


class Exchange:
    def __init__(self, cache_path, request_get=None):
        self.cache_path, self.request_get = cache_path, request_get

    def get(self, path, ttl=3600):
        if not re.fullmatch(r'/exchange/(?:search/\?q=[A-Za-z0-9%+_.~\-]*|(?:videos|series)/\d{1,10}/|skip/\d{1,10}/(?:download/)?)', path):
            raise FilterError('Invalid VideoSkip route')
        now = time.time()
        try:
            with sqlite3.connect(self.cache_path, timeout=1) as db:
                db.execute('CREATE TABLE IF NOT EXISTS videoskip (path TEXT PRIMARY KEY, fetched REAL, body TEXT)')
                db.execute('DELETE FROM videoskip WHERE fetched < ?', (now - 86400,))
                cached = db.execute('SELECT fetched, body FROM videoskip WHERE path=?', (path,)).fetchone()
            if cached and 0 <= now - cached[0] < ttl and len(cached[1].encode('utf-8')) <= MAX_BYTES:
                return cached[1]
        except (sqlite3.Error, TypeError):
            pass
        request_get = self.request_get
        if request_get is None:
            from requests import get
            request_get = get
        response = None
        try:
            global _last_request
            with _lock:
                time.sleep(max(0, 1 - (time.monotonic() - _last_request)))
                _last_request = time.monotonic()
                response = request_get(ORIGIN + path, timeout=(3.05, 6.05), stream=True,
                                       allow_redirects=False, headers={'User-Agent': 'Umbrella-Family/0.9 (VideoSkip browsing and availability)'})
            if response.status_code != 200:
                raise FilterError('VideoSkip unavailable (HTTP %s). No automatic retry; try later or import a file.' % response.status_code)
            chunks, size, started = [], 0, time.monotonic()
            for chunk in response.iter_content(chunk_size=16384):
                size += len(chunk)
                if size > MAX_BYTES or time.monotonic() - started > 15:
                    raise FilterError('VideoSkip response exceeded size/time limits')
                chunks.append(chunk)
            body = b''.join(chunks).decode('utf-8-sig')
        except FilterError:
            raise
        except Exception:
            raise FilterError('Could not retrieve VideoSkip data; try later or import a file')
        finally:
            if response is not None:
                response.close()
        try:
            with sqlite3.connect(self.cache_path, timeout=1) as db:
                db.execute('INSERT OR REPLACE INTO videoskip VALUES (?, ?, ?)', (path, now, body))
        except sqlite3.Error:
            pass
        return body

    def search(self, query, kind):
        query = clean(query)[:120]
        if not query:
            raise FilterError('Enter a title to search VideoSkip')
        return parse_search(self.get('/exchange/search/?' + urlencode({'q': query})), kind)


def browse(player):
    from resources.lib.modules import control
    import os
    import xbmcvfs
    from resources.lib.modules.family_filter_timing import episode_number
    episode = player.media_type == 'episode'
    if not re.fullmatch(r'tt\d{7,10}', str(player.imdb)):
        raise FilterError('Online VideoSkip needs the movie/show IMDb ID to verify results; use file import instead')
    meta = player.meta if isinstance(getattr(player, 'meta', None), dict) else {}
    query = meta.get('tvshowtitle' if episode else 'title') or player.name
    query = control.dialog.input('Search VideoSkip by ' + ('show title' if episode else 'movie title'), defaultt=query)
    if not query:
        raise FilterError('VideoSkip browsing cancelled')
    xbmcvfs.mkdirs(control.dataPath)
    client = Exchange(os.path.join(control.dataPath, 'family_filters.db'))
    results = client.search(query, player.media_type)
    if not results:
        raise FilterError('No VideoSkip titles with filters found for that search')
    selected = control.dialog.select('VideoSkip - choose exact ' + ('show' if episode else 'movie'), [row['title'] for row in results])
    if not isinstance(selected, int) or not 0 <= selected < len(results):
        raise FilterError('VideoSkip browsing cancelled')
    identifier = results[selected]['id']
    if episode:
        season, ep = episode_number(player.season), episode_number(player.episode, 1)
        video_id = parse_series(client.get('/exchange/series/%s/' % identifier), player.imdb, season, ep)
    else:
        video_id = identifier
    title = parse_title(client.get('/exchange/videos/%s/' % video_id))
    if title['kind'] != player.media_type:
        raise FilterError('VideoSkip returned a different media type')
    if episode:
        if (title['series'], title['season'], title['episode']) != (identifier, season, ep):
            raise FilterError('VideoSkip returned a different episode')
        if meta.get('episode_imdb') and meta['episode_imdb'] != title['imdb']:
            raise FilterError('VideoSkip episode IMDb identity does not match')
    elif title['imdb'] != player.imdb:
        raise FilterError('This VideoSkip title belongs to a different IMDb movie')
    if not title['skips']:
        raise FilterError('This VideoSkip entry has requests but no downloadable filters')
    selected = control.dialog.select('VideoSkip - choose filter to inspect', ['Skip file #' + skip for skip in title['skips']])
    if not isinstance(selected, int) or not 0 <= selected < len(title['skips']):
        raise FilterError('VideoSkip filter selection cancelled')
    skip = title['skips'][selected]
    info = parse_skip(client.get('/exchange/skip/%s/' % skip), video_id, skip)
    control.dialog.textviewer('VideoSkip filter details', '\n'.join([title['title'], info['author'],
        'Reference edition/platform: ' + info['edition'], info['description'],
        'This does not verify your stream or timing. File #' + skip]))
    if not control.dialog.yesno('VideoSkip', 'Download this filter for review? Timing still needs checking.'):
        raise FilterError('VideoSkip download cancelled')
    data = parse_file(client.get(info['path'], ttl=86400), '.skp')
    metadata = data['metadata']
    metadata.update({key: info[key] for key in ('author', 'edition', 'description')})
    metadata.update(title=title['title'], type=player.media_type, videoskip_id=skip,
                    filename='VideoSkip-%s.skp' % skip, provider_url=ORIGIN + '/exchange/skip/%s/' % skip)
    if episode:
        # A verified series IMDb + exact season/episode is sufficient. Preserve
        # the provider's episode ID separately; never substitute the show ID.
        metadata.update(showimdb=player.imdb, season=season, episode=ep, provider_episode_imdb=title['imdb'])
    else:
        metadata['imdb'] = title['imdb']
    return data
