# -*- coding: utf-8 -*-
"""Non-blocking, per-window provider availability; never stream compatibility."""
import os
import re
from threading import RLock, Thread

import xbmcvfs
from resources.lib.modules import control
from resources.lib.modules.family_filter_provider import availability
from resources.lib.modules import family_filter_discovery as videoskip
from resources.lib.modules.family_filters import FilterError

PROPERTY = 'umbrellafamily.cleanstream.status'
MESSAGES = {
    'available': 'CleanStream filters available - timing unverified',
    'missing': 'No CleanStream filters found',
    'unavailable': 'CleanStream unavailable - lookup failed',
}


class SourceStatus:
    def __init__(self, window, metadata):
        self.window = window
        self.metadata = dict(metadata) if isinstance(metadata, dict) else {}
        self.lock = RLock()
        self.closed = False
        self.started = False
        self.thread = None
        self.video_thread = None
        self.video_result = None
        self.clean_text = 'CleanStream: not checked'
        self.video_text = 'VideoSkip: not checked'
        self.enabled = control.setting('family.show_status') != 'false'
        self.filtering = control.setting('family.enabled') == 'true'

    def _publish(self, text):
        with self.lock:
            if not self.closed:
                try:
                    self.window.setProperty(PROPERTY, text)
                except Exception:
                    pass  # A closed UI must never interrupt source selection.

    def _render(self):
        self._publish(self.clean_text + ' | ' + self.video_text +
                      ' | timing unverified' + (' (filtering off)' if not self.filtering else ''))

    def start(self):
        with self.lock:
            if self.started or self.closed:
                return
            self.started = True
            if not self.enabled:
                self._publish('')
                return
            media_type = self.metadata.get('mediatype')
            is_episode = self.metadata.get('episode') not in (None, '', 'None')
            imdb = str(self.metadata.get('imdb') or '')
            lookup_clean = False
            if media_type in ('episode', 'tvshow', 'season') or is_episode:
                self.clean_text = 'CleanStream: unsupported for episodes'
            elif media_type not in (None, '', 'movie'):
                self.clean_text = 'CleanStream: media type not supported'
            elif control.setting('family.cleanstream') == 'false':
                self.clean_text = 'CleanStream lookup disabled'
            elif not re.fullmatch(r'tt\d{7,10}', imdb):
                self.clean_text = 'CleanStream: no movie IMDb ID available'
            else:
                self.clean_text = 'Checking CleanStream...'
                lookup_clean = True
            try:
                subject = videoskip.identity(self.metadata)
                self.video_text = 'Checking VideoSkip' + (' exact-episode' if subject['kind'] == 'episode' else '') + '...'
            except FilterError:
                subject = None
                self.video_text = 'VideoSkip: exact-episode/title identity missing - not checked'
            self._render()
            if lookup_clean:
                self.thread = Thread(target=self._lookup, args=(imdb,))
                self.thread.daemon = True
                self.thread.start()
            if subject:
                self.video_thread = Thread(target=self._lookup_video, args=(subject,))
                self.video_thread.daemon = True
                self.video_thread.start()

    def _lookup(self, imdb):
        try:
            xbmcvfs.mkdirs(control.dataPath)
            state = availability(control.setting('family.server') or 'https://cleanstream.elfhosted.com',
                                 imdb, os.path.join(control.dataPath, 'family_filters.db'))
            text = MESSAGES.get(state, MESSAGES['unavailable'])
        except Exception:
            text = MESSAGES['unavailable']
        with self.lock:
            self.clean_text = text.replace(' - timing unverified', '')
            self._render()

    def _lookup_video(self, subject):
        try:
            xbmcvfs.mkdirs(control.dataPath)
            result = videoskip.availability(os.path.join(control.dataPath, 'family_filters.db'), subject,
                                           cancelled=lambda: self.closed or control.monitor.abortRequested())
        except Exception:
            result = dict(state='unavailable', entries=[], partial=True)
        messages = {'available': 'filters found', 'missing': 'none found in search',
                    'unchecked': 'not confirmed - search limit reached', 'unavailable': 'lookup failed'}
        with self.lock:
            if self.closed:
                return
            self.video_result = result
            self.video_text = 'VideoSkip: ' + messages.get(result['state'], 'lookup failed')
            if result['state'] == 'available' and result['partial']:
                self.video_text += ' (partial search)'
            if subject['kind'] == 'episode':
                self.video_text += ' S%02dE%02d' % (subject['season'], subject['episode'])
            self._render()

    def inspect(self):
        """Read-only remote context action, independent of stream selection."""
        with self.lock:
            if self.closed or not self.enabled:
                return
            result = self.video_result
            summary = self.clean_text + '\n' + self.video_text
        control.dialog.textviewer('Family filter availability', summary + '\n\n'
            'Availability is for this title/episode, NOT the highlighted stream. Timing and coverage are unverified. '
            'No filter is applied or downloaded here. CleanStream filters are reviewed before playback. '
            'Available VideoSkip files can be inspected next. Sources remain selectable during background lookups.')
        if self.closed or not result or not result['entries']:
            return
        entries = result['entries']
        selected = control.dialog.select('VideoSkip - inspect filter edition and notes',
            [entry['title'] + ' - filter #' + entry['skip'] for entry in entries])
        if self.closed or not isinstance(selected, int) or not 0 <= selected < len(entries):
            return
        try:
            text = videoskip.details(os.path.join(control.dataPath, 'family_filters.db'), entries[selected])
            if not self.closed:
                control.dialog.textviewer('VideoSkip filter details - timing unverified', text)
        except Exception:
            if not self.closed:
                control.dialog.ok('VideoSkip details unavailable', 'Could not retrieve this filter\'s notes. '
                                  'No filter was downloaded or applied. Try the pre-playback VideoSkip browser later.')

    def close(self):
        with self.lock:
            self.closed = True
        # Do not hold up window closing for a network request. Late results are
        # cached but cannot update this window or a subsequently opened title.
