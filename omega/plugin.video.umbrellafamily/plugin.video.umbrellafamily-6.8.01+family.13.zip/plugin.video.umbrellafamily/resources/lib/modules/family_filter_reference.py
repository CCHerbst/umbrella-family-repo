# -*- coding: utf-8 -*-
"""Adult-only reference preview and a bounded, read-only device capture check."""
import hashlib

import xbmc
import xbmcvfs
from resources.lib.modules import control
from resources.lib.modules.family_filters import FilterError
from resources.lib.modules.family_filter_timing import reference_image


def show_reference(reference, instructions=None):
    # This deliberately never starts/seeks an unfiltered video. The adult measures
    # the matching timestamp separately, then returns here before filtered playback.
    instructions = instructions or ('Reference time: %.3f seconds\n%s\n\n'
                    'Adult setup only. Find this same moment in your video beforehand, '
                    'then enter its measured timestamp on the next screen. '
                    'This preview does not play or automatically align the movie. '
                    'One matching image cannot verify the whole timeline.' %
                    (reference['time'], reference.get('description', '')))
    if not reference.get('image'):
        control.dialog.textviewer('Umbrella Family - Reference landmark', instructions)
        return
    raw, extension = reference_image(reference['image'])
    path = 'special://temp/umbrella-family-reference-%s.%s' % (hashlib.sha256(raw).hexdigest(), extension)
    handle = xbmcvfs.File(path, 'wb')
    try:
        try:
            if not handle.write(bytearray(raw)):
                raise FilterError('Could not display the reference image')
        finally:
            handle.close()
        import xbmcgui

        class ReferenceDialog(xbmcgui.WindowXMLDialog):
            def onInit(self):
                self.setProperty('family.reference.image', path)
                self.setProperty('family.reference.text', instructions)
                self.setFocusId(100)

            def onClick(self, control_id):
                if control_id == 100:
                    self.accepted = True
                    self.close()

            def onAction(self, action):
                if action.getId() in (9, 10, 92, 216):
                    self.close()

        window = ReferenceDialog('family_reference.xml', control.addonPath(), 'Default', '1080i')
        window.accepted = False
        window.doModal()
        accepted = window.accepted
        del window
        if not accepted:
            raise FilterError('Reference alignment cancelled')
    finally:
        xbmcvfs.delete(path)


def capture_probe():
    """Never adjusts timings; a nonblank frame is only a prerequisite for research."""
    player = xbmc.Player()
    heading = 'Umbrella Family - Frame capture test'
    if not player.isPlayingVideo():
        control.dialog.ok(heading, 'Start a video, then run this test. It does not change playback or filtering.')
        return
    try:
        capture = xbmc.RenderCapture()
        capture.capture(160, 90)
        pixels = capture.getImage(1500)
        if len(pixels) != 160 * 90 * 4:
            result = 'No usable video frame was returned.'
        else:
            # Ignore alpha; black captures are common with Android surface rendering.
            rgb = [value for index, value in enumerate(pixels) if index % 4 != 3]
            if max(rgb) - min(rgb) < 8 or sum(rgb) / len(rgb) < 3:
                result = 'The captured frame was black or nearly uniform. Try a bright scene once.'
            else:
                result = 'A nonblank image was returned. This does not verify that it is the video, or that its timestamp is accurate.'
        del capture
    except Exception:
        result = 'Frame capture failed on this playback configuration.'
    control.dialog.ok(heading, result + '\nExperimental reference matching is available in Parent Audit for supported captures. This test does not verify matching accuracy. No images were saved or uploaded; hardware acceleration was not changed.')
