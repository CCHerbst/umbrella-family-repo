# -*- coding: utf-8 -*-
"""Bounded CleanStream requests and a small, expiring local response cache."""
import json
import re
import sqlite3
import time
from urllib.parse import urlsplit

from resources.lib.modules.family_filters import FilterError, MAX_BYTES, parse_cleanstream


class NoFilters(FilterError):
    pass


def parse_movie_response(data, imdb):
    # Empty filters mean missing coverage only if the identity/type are correct.
    if isinstance(data, dict) and data.get('imdbId') == imdb and data.get('type') == 'movie' and data.get('segments') == []:
        raise NoFilters('No CleanStream filters found for this movie')
    return parse_cleanstream(data, imdb)


def fetch_cleanstream(base_url, imdb, cache_path, request_get=None):
    if not re.fullmatch(r'tt\d{7,10}', str(imdb)):
        raise FilterError('CleanStream requires an IMDb movie ID')
    base_url = base_url.strip().rstrip('/')
    parsed = urlsplit(base_url)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password
            or parsed.query or parsed.fragment):
        raise FilterError('Use an HTTPS CleanStream server URL without credentials or query parameters')
    key = base_url + '/api/filters/' + imdb
    cached = None
    try:
        with sqlite3.connect(cache_path, timeout=2) as db:
            db.execute('CREATE TABLE IF NOT EXISTS filters (url TEXT PRIMARY KEY, fetched REAL, body TEXT)')
            db.execute('DELETE FROM filters WHERE fetched < ?', (time.time() - 86400,))
            cached = db.execute('SELECT body FROM filters WHERE url=?', (key,)).fetchone()
        if cached:
            return parse_movie_response(json.loads(cached[0]), imdb)
    except (sqlite3.Error, ValueError):
        pass  # A cache failure must never turn a valid network result into unfiltered playback.
    if request_get is None:
        from requests import get
        request_get = get
    response = None
    try:
        response = request_get(key, timeout=(3.05, 6.05), stream=True, allow_redirects=False)
        if response.status_code == 404:
            raise NoFilters('No CleanStream filters found for this movie')
        if response.status_code != 200:
            raise FilterError('CleanStream is unavailable (HTTP %s)' % response.status_code)
        chunks, size, started = [], 0, time.monotonic()
        for chunk in response.iter_content(chunk_size=16384):
            size += len(chunk)
            if size > MAX_BYTES or time.monotonic() - started > 15:
                raise FilterError('CleanStream response exceeded the size or time limit')
            chunks.append(chunk)
        body = b''.join(chunks).decode('utf-8')
        result = parse_movie_response(json.loads(body), imdb)
    except FilterError:
        raise
    except Exception:
        # Do not include signed URLs, credentials or response bodies in errors/logs.
        raise FilterError('Could not retrieve valid CleanStream filters; playback was not started')
    finally:
        if response is not None:
            response.close()
    try:
        with sqlite3.connect(cache_path, timeout=2) as db:
            db.execute('CREATE TABLE IF NOT EXISTS filters (url TEXT PRIMARY KEY, fetched REAL, body TEXT)')
            db.execute('INSERT OR REPLACE INTO filters VALUES (?, ?, ?)', (key, time.time(), body))
    except sqlite3.Error:
        pass
    return result


def availability(base_url, imdb, cache_path):
    """Read-only title status, never evidence that a particular release matches."""
    key = base_url.strip().rstrip('/') + '/api/filters/' + str(imdb)
    lifetimes = {'available': 86400, 'missing': 600, 'unavailable': 60}
    now = time.time()
    try:
        with sqlite3.connect(cache_path, timeout=2) as db:
            db.execute('CREATE TABLE IF NOT EXISTS filter_status (url TEXT PRIMARY KEY, fetched REAL, state TEXT)')
            db.execute('DELETE FROM filter_status WHERE fetched < ?', (now - 86400,))
            cached = db.execute('SELECT fetched, state FROM filter_status WHERE url=?', (key,)).fetchone()
        if cached and cached[1] in lifetimes and 0 <= now - cached[0] < lifetimes[cached[1]]:
            return cached[1]
    except (sqlite3.Error, TypeError, ValueError):
        pass
    try:
        fetch_cleanstream(base_url, imdb, cache_path)
        state = 'available'
    except NoFilters:
        state = 'missing'
    except Exception:
        state = 'unavailable'
    try:
        with sqlite3.connect(cache_path, timeout=2) as db:
            db.execute('INSERT OR REPLACE INTO filter_status VALUES (?, ?, ?)', (key, now, state))
    except sqlite3.Error:
        pass
    return state
