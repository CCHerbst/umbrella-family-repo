# -*- coding: utf-8 -*-
"""Experimental local landmark matcher. Proposals only, never safety certification.

Single images cannot verify editions or drift. Reject weak, static, repeated,
edge-of-window, undersampled and capture-clock-unstable matches.
"""
import base64
from io import BytesIO
import math
import time

from resources.lib.modules.family_filters import FilterError, number
from resources.lib.modules.family_filter_timing import reference_image


def image_module():
    try:
        from PIL import Image
        return Image
    except ImportError:
        raise FilterError('Kodi image decoding is unavailable. Use manual landmark alignment')


def reference_picture(reference):
    raw, _ = reference_image(reference.get('image', ''))
    Image = image_module()
    try:
        with Image.open(BytesIO(raw)) as original:
            if original.width * original.height > 4000000 or original.format not in ('JPEG', 'PNG'):
                raise ValueError()
            image = original.convert('RGB')
            image.load()
        return image
    except Exception:
        raise FilterError('The reference image could not be decoded safely')


def signature(image):
    Image = image_module()
    small = image.convert('RGB').resize((64, 36), getattr(Image, 'Resampling', Image).BILINEAR)
    rgb = list(small.getdata())
    gray = [(r * 0.299 + g * 0.587 + b * 0.114) / 255 for r, g, b in rgb]
    mean = sum(gray) / len(gray)
    variance = sum((value - mean) ** 2 for value in gray) / len(gray)
    if variance < 0.003 or mean < 0.035 or mean > 0.965:
        raise FilterError('Black, uniform or low-detail frame; automatic matching is not usable')
    scale = math.sqrt(variance)
    return tuple((value - mean) / scale for value in gray), tuple(channel / 255 for pixel in rgb for channel in pixel)


def distance(reference, candidate):
    structural = sum(abs(a - b) for a, b in zip(reference[0], candidate[0])) / len(reference[0])
    color = sum(abs(a - b) for a, b in zip(reference[1], candidate[1])) / len(reference[1])
    return structural, color


def choose_match(samples, start, end):
    """Samples are (actual timestamp, structural error, color error)."""
    if len(samples) < 24:
        raise FilterError('Too few usable frames for an alignment proposal')
    ordered = sorted(samples)
    if ordered[0][0] > start + 0.5 or ordered[-1][0] < end - 0.5:
        raise FilterError('Capture did not cover the requested search window')
    if any(b[0] - a[0] > 0.5 for a, b in zip(ordered, ordered[1:])):
        raise FilterError('Capture timing was too sparse or unstable')
    best = min(ordered, key=lambda sample: sample[1] + sample[2])
    if best[1] > 0.20 or best[2] > 0.10:
        raise FilterError('No sufficiently close reference-image match was found')
    if min(best[0] - start, end - best[0]) < 0.5:
        raise FilterError('Best match is at the search boundary; adjust the approximate offset and retry')
    score = best[1] + best[2]
    close = [sample[0] for sample in ordered if sample[1] + sample[2] <= score + 0.025]
    if max(close) - min(close) > 0.5:
        raise FilterError('The landmark is static or repeated; its timestamp is ambiguous')
    rivals = [sample[1] + sample[2] for sample in ordered if abs(sample[0] - best[0]) >= 0.75]
    if not rivals or min(rivals) - score < 0.06:
        raise FilterError('Several frames look too similar; use manual alignment')
    return best[0]


def scan(player, reference, approximate_offset, check, wait, capture_factory, paused, progress):
    """Explicit adult setup: seek/play a bounded region. Host owns stopping it.

    check() raises on cancellation/ownership changes; wait() is interruptible.
    No audio/subtitle commands, network, configuration changes or file writes.
    """
    picture = reference_picture(reference)
    expected = signature(picture)
    target = number(number(reference['time']) + number(approximate_offset, -3600, 3600))
    check()
    duration = number(player.getTotalTime(), minimum=1)
    start, end = max(0, target - 10), min(duration - 0.25, target + 10)
    if end - start < 3:
        raise FilterError('Reference is too close to the video boundary')
    capture = capture_factory()
    aspect = number(capture.getAspectRatio(), minimum=0.3, maximum=4)
    if abs(aspect / (picture.width / picture.height) - 1) > 0.05:
        raise FilterError('Reference and video aspect ratios differ; use manual alignment')
    width, height = 160, max(40, min(320, int(160 / aspect)))
    Image = image_module()
    check()
    player.seekTime(start)
    if paused():
        check()
        player.pause()  # Explicitly authorized scan needs forward playback.
    deadline = time.monotonic() + 45
    seek_deadline = time.monotonic() + 6
    while True:
        check()
        if time.monotonic() > deadline:
            raise FilterError('Timed out waiting for the alignment seek')
        position = number(player.getTime())
        if start - 0.25 <= position <= start + 0.5:
            break
        if time.monotonic() > seek_deadline:
            raise FilterError('The player did not land at the requested scan start')
        wait(0.1)
    capture.capture(width, height)
    samples, pictures, last_position = [], {}, -1
    best_score = float('inf')
    last_raw, distinct, bad = None, 0, 0
    while True:
        check()
        if time.monotonic() > deadline:
            raise FilterError('Alignment scan timed out or playback stalled')
        before = number(player.getTime())
        if before >= end:
            break
        raw = bytes(capture.getImage(200))
        check()
        after = number(player.getTime())
        if len(raw) != width * height * 4:
            raise FilterError('Kodi did not return video pixels; manual alignment is required on this device')
        if not 0 <= after - before <= 0.2:
            bad += 1
            if bad > 4:
                raise FilterError('Capture timestamps are unstable')
            wait(0.1)
            continue
        position = (before + after) / 2
        if position <= last_position:
            wait(0.1)
            continue
        if last_position >= 0 and position - last_position > 0.5:
            raise FilterError('Playback jumped during the alignment scan')
        image = Image.frombytes('RGBA', (width, height), raw, 'raw', 'BGRA').convert('RGB')
        try:
            score = distance(expected, signature(image))
        except FilterError:
            score = (10, 10)  # A black frame is never a successful match.
        samples.append((position, score[0], score[1]))
        if len(samples) > 400:
            raise FilterError('Alignment scan exceeded its frame budget')
        if score[0] + score[1] < best_score:
            best_score = score[0] + score[1]
            pictures = {position: image}
        if raw != last_raw:
            distinct += 1
        last_raw, last_position = raw, position
        progress('Searching reference: %d%% (unfiltered)' % min(100, int(100 * (position - start) / (end - start))))
        wait(0.1)
    if distinct < 8:
        raise FilterError('Capture is frozen or lacks enough changing frames')
    actual = choose_match(samples, start, end)
    offset = number(actual - reference['time'], -3600, 3600)
    # Only two small images in a temporary parent preview; never upload frames.
    comparison = Image.new('RGB', (640, 180))
    comparison.paste(picture.resize((320, 180)), (0, 0))
    comparison.paste(pictures[actual].resize((320, 180)), (320, 0))
    output = BytesIO()
    comparison.save(output, format='PNG')
    return dict(offset=offset, actual=actual, preview='data:image/png;base64,' + base64.b64encode(output.getvalue()).decode('ascii'))
