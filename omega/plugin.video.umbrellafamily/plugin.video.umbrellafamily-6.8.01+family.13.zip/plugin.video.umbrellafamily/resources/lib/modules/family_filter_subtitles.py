# -*- coding: utf-8 -*-
"""Pre-playback OpenSubtitles retrieval; no player access or silent fallback.

Protocol: https://ai.opensubtitles.com/api-docs (OpenSubtitles REST v1).
Use a configured Family application key, not the inherited upstream app key.
Only title identity/language are sent; stream URLs and filenames stay local.
"""
import hashlib
import json
import os
import re
import time
from difflib import SequenceMatcher
from threading import Lock
from urllib.parse import unquote, urljoin, urlsplit

from resources.lib.modules.family_filters import FilterError, MAX_BYTES, subtitle_mutes
from resources.lib.modules.family_filter_timing import episode_number, validate_identity

API_HOSTS = frozenset(('api.opensubtitles.com', 'vip-api.opensubtitles.com'))
DOWNLOAD_HOSTS = frozenset(('www.opensubtitles.com', 'dl.opensubtitles.com'))
MAX_RESULTS = 60
_PACE_LOCK = Lock()
_LAST_REQUEST = 0.0


class SubtitleCancelled(FilterError):
    pass


def clean_text(value, limit=200):
    """Remote text is display-only: strip Kodi markup and control characters."""
    if not isinstance(value, str):
        return ''
    return re.sub(r'[\[\]\x00-\x1f\x7f]', '', value)[:limit]


def imdb_number(value):
    if isinstance(value, bool):
        raise FilterError('Subtitles require a valid IMDb identity')
    match = re.fullmatch(r'(?:tt)?(\d{1,10})', str(value))
    if not match or int(match[1]) <= 0:
        raise FilterError('Subtitles require a valid IMDb identity')
    return int(match[1])


def language_code(value):
    value = str(value or '').strip().lower()
    if not re.fullmatch(r'[a-z]{2,3}(?:-[a-z]{2})?', value):
        raise FilterError('Set a subtitle language code, for example en or pt-br')
    return value


def identity(media_type, imdb, season=None, episode=None, episode_imdb=''):
    if not re.fullmatch(r'tt\d{7,10}', str(imdb)):
        raise FilterError('Automatic subtitles require an IMDb movie or show ID')
    result = {'type': media_type, 'imdb': imdb}
    if media_type == 'episode':
        result.update(season=episode_number(season), episode=episode_number(episode, 1))
        if episode_imdb:
            if not re.fullmatch(r'tt\d{7,10}', str(episode_imdb)):
                raise FilterError('Invalid IMDb episode ID')
            result['episode_imdb'] = episode_imdb
    elif media_type != 'movie':
        raise FilterError('Automatic subtitles support movies and single episodes only')
    return result


def search_parameters(expected, language):
    params = {'languages': language_code(language), 'foreign_parts_only': 'exclude',
              'ai_translated': 'exclude', 'machine_translated': 'exclude', 'page': 1}
    if expected['type'] == 'movie':
        params.update(type='movie', imdb_id=imdb_number(expected['imdb']))
    else:
        params.update(type='episode', parent_imdb_id=imdb_number(expected['imdb']),
                      season_number=expected['season'], episode_number=expected['episode'])
    return params


def candidates(payload, expected, language, release):
    if not isinstance(payload, dict) or not isinstance(payload.get('data'), list):
        raise FilterError('OpenSubtitles returned an invalid search response')
    if len(payload['data']) > MAX_RESULTS:
        raise FilterError('Too many subtitle results in one response')
    language = language_code(language)
    result, seen = [], set()
    for row in payload['data']:
        try:
            attrs = row['attributes']
            feature = attrs['feature_details']
            if str(attrs.get('language', '')).lower() != language:
                continue
            # Forced-only captions cannot cover dialogue. Reject translations
            # flagged by the provider; absent optional flags make no guarantee.
            if attrs.get('foreign_parts_only') is not False:
                continue
            if attrs.get('ai_translated', False) is not False or attrs.get('machine_translated', False) is not False:
                continue
            if feature['feature_type'].lower() != expected['type']:
                continue
            metadata = {'type': expected['type']}
            if expected['type'] == 'movie':
                if imdb_number(feature['imdb_id']) != imdb_number(expected['imdb']):
                    continue
                metadata['imdb'] = expected['imdb']
            else:
                if (imdb_number(feature['parent_imdb_id']) != imdb_number(expected['imdb']) or
                        episode_number(feature['season_number']) != expected['season'] or
                        episode_number(feature['episode_number'], 1) != expected['episode']):
                    continue
                if expected.get('episode_imdb') and imdb_number(feature['imdb_id']) != imdb_number(expected['episode_imdb']):
                    continue
                metadata.update(showimdb=expected['imdb'], season=expected['season'], episode=expected['episode'])
            files = attrs['files']
            # Multi-disc subtitles need concatenation, which this path cannot verify.
            if not isinstance(files, list) or len(files) != 1:
                continue
            file = files[0]
            file_id = file['file_id']
            if type(file_id) is not int or file_id <= 0 or file_id in seen:
                continue
            filename = file['file_name']
            edition = attrs.get('release') or filename
            if not isinstance(filename, str) or not filename or not isinstance(edition, str):
                continue
            validate_identity(expected['type'], expected['imdb'], expected.get('season'), expected.get('episode'),
                              metadata, filename + ' ' + edition, expected.get('episode_imdb', ''))
            if re.search(r'(?i)(?:^|[ ._-])(?:cd|disc|disk)[ ._-]*\d', filename + ' ' + edition):
                continue
            filename, edition = clean_text(filename), clean_text(edition)
            metadata.update(filename=filename, edition=edition, title=clean_text(feature.get('movie_name') or feature.get('title')),
                            author=clean_text((attrs.get('uploader') or {}).get('name')), language=language,
                            provider='OpenSubtitles', provider_file_id=file_id,
                            notes='Provider identity matched; edition, completeness and timing remain unverified.')
            # Ranking is local convenience only, never a confidence/safety score.
            score = max(SequenceMatcher(None, release.lower()[:250], name.lower()).ratio()
                        for name in (filename, edition))
            result.append({'file_id': file_id, 'metadata': metadata, 'score': score})
            seen.add(file_id)
        except (KeyError, TypeError, ValueError, AttributeError, FilterError):
            continue  # One malformed/contradictory record must not become a candidate.
    return sorted(result, key=lambda row: (-row['score'], row['file_id']))


def safe_url(value, hosts):
    try:
        parsed = urlsplit(value)
        if (not isinstance(value, str) or len(value) > 8192 or re.search(r'[\x00-\x20\x7f\\]', value) or
                parsed.scheme != 'https' or parsed.hostname not in hosts or parsed.port not in (None, 443) or
                parsed.username or parsed.password or parsed.fragment):
            raise ValueError()
    except (TypeError, ValueError):
        raise FilterError('Subtitle service supplied an unsafe URL; use manual import')
    return value


class Client:
    def __init__(self, api_key, username, password, version, request=None, cancelled=None, wait=None):
        if not all(isinstance(v, str) and v.strip() for v in (api_key, username, password)):
            raise FilterError('Set the Family subtitle API key and your OpenSubtitles username/password in Settings first')
        if any('\r' in v or '\n' in v for v in (api_key, version)):
            raise FilterError('Invalid subtitle API configuration')
        self.api_key, self.username, self.password = api_key.strip(), username, password
        self.version = version
        self.host, self.token = 'api.opensubtitles.com', ''
        self.cancelled = cancelled or (lambda: False)
        self.wait = wait or (lambda seconds: time.sleep(seconds))
        self.session = None
        if request is None:
            from requests import Session
            self.session = Session()
            self.session.trust_env = False  # No ambient .netrc credentials/proxy auth.
            request = self.session.request
        self.request = request

    def close(self):
        self.token = self.password = self.api_key = ''
        if self.session is not None:
            self.session.close()

    def check(self):
        if self.cancelled():
            raise SubtitleCancelled('Subtitle retrieval cancelled; playback was not started')

    def _fetch(self, method, url, headers, **kwargs):
        global _LAST_REQUEST
        response = None
        try:
            with _PACE_LOCK:
                self.check()
                pause = max(0, 1.0 - (time.monotonic() - _LAST_REQUEST))
                if pause:
                    self.wait(pause)
                    self.check()
                _LAST_REQUEST = time.monotonic()
            if self.session is not None:
                self.session.cookies.clear()
            response = self.request(method, url, headers=headers, timeout=(3.05, 6.05),
                                    stream=True, allow_redirects=False, **kwargs)
            self.check()
            status = response.status_code
            if status in (301, 302, 303, 307, 308):
                return None, response.headers.get('Location', '')
            if status in (401, 403):
                raise FilterError('OpenSubtitles rejected the credentials or API access; check settings. No automatic retry.')
            if status in (406, 429):
                raise FilterError('OpenSubtitles download allowance or rate limit reached; try later or import a file')
            if status != 200:
                raise FilterError('Subtitle service unavailable (HTTP %s); playback was not started' % status)
            length = response.headers.get('Content-Length')
            if length and (not str(length).isdigit() or int(length) > MAX_BYTES):
                raise FilterError('Subtitle response exceeds the size limit')
            chunks, size, started = [], 0, time.monotonic()
            for chunk in response.iter_content(chunk_size=16384):
                self.check()
                size += len(chunk)
                if size > MAX_BYTES or time.monotonic() - started > 15:
                    raise FilterError('Subtitle response exceeded its size or time limit')
                chunks.append(chunk)
            return b''.join(chunks), None
        except FilterError:
            raise
        except Exception:
            # Requests exceptions can contain tokens, passwords, or signed URLs.
            raise FilterError('Could not retrieve subtitles; playback was not started') from None
        finally:
            if response is not None:
                response.close()

    def api(self, method, endpoint, **kwargs):
        url = 'https://' + self.host + '/api/v1/' + endpoint
        headers = {'Api-Key': self.api_key, 'User-Agent': 'UmbrellaFamily v' + self.version,
                   'Accept': 'application/json', 'Content-Type': 'application/json'}
        if self.token:
            headers['Authorization'] = 'Bearer ' + self.token
        for attempt in range(2):
            body, redirect = self._fetch(method, url, headers, **kwargs)
            if body is not None:
                try:
                    result = json.loads(body.decode('utf-8'))
                    if not isinstance(result, dict):
                        raise ValueError()
                    return result
                except (ValueError, UnicodeError):
                    raise FilterError('Subtitle service returned invalid JSON') from None
            # Never replay login credentials or quota-consuming download POSTs.
            if method != 'GET' or attempt or not redirect:
                raise FilterError('Unexpected subtitle service redirect')
            url = safe_url(urljoin(url, redirect), API_HOSTS)
        raise FilterError('Subtitle service redirect limit reached')

    def login(self):
        result = self.api('POST', 'login', json={'username': self.username, 'password': self.password})
        host, token = result.get('base_url'), result.get('token')
        if host not in API_HOSTS or not isinstance(token, str) or not token or re.search(r'\s', token):
            raise FilterError('Invalid subtitle authentication response')
        self.host, self.token = host, token

    def search(self, expected, language, release):
        params = search_parameters(expected, language)
        self.login()
        return candidates(self.api('GET', 'subtitles', params=params), expected, language, release)

    def download(self, candidate, words):
        file_id = candidate['file_id']
        if type(file_id) is not int or file_id <= 0:
            raise FilterError('Invalid subtitle file selection')
        # Request SRT without FPS conversion or provider-side timing guesses.
        result = self.api('POST', 'download', json={'file_id': file_id, 'sub_format': 'srt'})
        url = safe_url(result.get('link'), DOWNLOAD_HOSTS)
        for attempt in range(3):
            # Never forward the application key, account token, or source headers.
            body, redirect = self._fetch('GET', url, {'User-Agent': 'UmbrellaFamily v' + self.version})
            if body is not None:
                try:
                    text = body.decode('utf-8-sig')
                except UnicodeError:
                    raise FilterError('Downloaded subtitles are not UTF-8 text') from None
                parsed = subtitle_mutes(text, words)
                parsed['metadata'].update(candidate['metadata'])
                parsed['metadata']['fingerprint'] = hashlib.sha256(body).hexdigest()
                parsed['source'] = 'OpenSubtitles word silencing'
                return parsed
            if not redirect or attempt == 2:
                raise FilterError('Subtitle download redirect limit reached')
            url = safe_url(urljoin(url, redirect), DOWNLOAD_HOSTS)
        raise FilterError('Subtitle download failed')


def retrieve(player, stream_url, control):
    """Kodi UI boundary. Playback remains stopped until existing filter review."""
    meta = getattr(player, 'meta', None)
    episode_imdb = meta.get('episode_imdb', '') if isinstance(meta, dict) else ''
    expected = identity(player.media_type, player.imdb, getattr(player, 'season', None),
                        getattr(player, 'episode', None), episode_imdb)
    language = language_code(control.setting('family.subtitle_language') or 'en')
    words = control.setting('family.words')
    if not str(words or '').strip():
        raise FilterError('Configure the words to silence before downloading subtitles')
    release = unquote(os.path.basename(urlsplit(stream_url.split('|', 1)[0]).path))[:250]
    progress = control.progressDialog
    client = Client(control.setting('family.subtitle_api_key'), control.setting('opensubsusername'),
                    control.setting('opensubspassword'), control.addonVersion,
                    cancelled=lambda: control.monitor.abortRequested() or progress.iscanceled(),
                    wait=control.monitor.waitForAbort)
    try:
        progress.create('Family subtitle lookup', 'Searching OpenSubtitles for this title and language...')
        try:
            rows = client.search(expected, language, release)
        finally:
            progress.close()
        if not rows:
            raise FilterError('No eligible subtitles found on the first results page. Choose a local matching SRT/VTT file.')
        labels = ['%s | %s | %s' % (language, row['metadata']['edition'], row['metadata']['filename']) for row in rows]
        selected = control.dialog.select('Choose subtitle edition - timing UNVERIFIED', labels)
        if type(selected) is not int or selected < 0 or selected >= len(rows):
            raise SubtitleCancelled('Subtitle selection cancelled; playback was not started')
        row = rows[selected]
        if not control.dialog.yesno('Download subtitles for Family Filters?',
                'Title: %s\nRelease: %s\nLanguage: %s\n\nThis uses your OpenSubtitles download allowance. '
                'It is not a verified timing or complete-dialogue match. Download and review before playback?' %
                (row['metadata']['title'], row['metadata']['edition'], language)):
            raise SubtitleCancelled('Subtitle download cancelled; playback was not started')
        progress.create('Family subtitle download', 'Downloading and checking subtitles...')
        try:
            return client.download(row, words)
        finally:
            progress.close()
    finally:
        client.close()
