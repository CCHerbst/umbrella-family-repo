# -*- coding: utf-8 -*-
"""Opt-in filtering: review each movie/episode, then monitor its original timeline."""
import os
import re
import time
import uuid
from json import dumps, loads
from threading import Event, RLock, Thread, current_thread
from urllib.parse import unquote, urlsplit

import xbmc
import xbmcvfs

from resources.lib.modules import control
from resources.lib.modules.family_filters import (CATEGORIES, MAX_BYTES, FilterError, PlaybackFilter,
                                                  compile_timeline, merge_timelines, number, parse_file,
                                                  skip_target, subtitle_mutes)
from resources.lib.modules.family_filter_timing import (alignment_offset, episode_number, forget_timing,
    read_timing, save_timing, timing_key, validate_identity)
from resources.lib.modules.family_filter_audit import AuditModel, audit_rows

HEADING = 'Umbrella Family - Filters (beta)'
OWNER = 'umbrellafamily.family.owner'


def enabled():
    return control.setting('family.enabled') == 'true'


def block_direct():
    if not enabled():
        return False
    control.dialog.ok(HEADING, 'This playback route cannot apply family filters. Open a movie or individual episode from its title page instead.')
    return True


def read_file(filename):
    handle = xbmcvfs.File(filename)
    try:
        if handle.size() > MAX_BYTES:
            raise FilterError('File exceeds 2 MiB')
        return handle.read(MAX_BYTES + 1)
    finally:
        handle.close()


def load_subtitles(player=None, url=None):
    if control.setting('family.subtitle_source') == '1':
        from resources.lib.modules.family_filter_subtitles import retrieve, SubtitleCancelled
        try:
            if player is None or not url:
                raise FilterError('Title and source metadata are required for online subtitles')
            return retrieve(player, url, control)
        except SubtitleCancelled:
            raise
        except FilterError as error:
            if not control.dialog.yesno(HEADING, str(error) + '\n\nChoose a local SRT/VTT file instead?'):
                raise
    filename = control.dialog.browseSingle(1, 'Choose matching SRT or WebVTT subtitles', 'files', '.srt|.vtt',
                                           defaultt=control.setting('family.folder'))
    if not filename:
        raise FilterError('No subtitles selected; playback was not started')
    result = subtitle_mutes(read_file(filename), control.setting('family.words'))
    result['metadata']['filename'] = os.path.basename(filename)
    return result


def parse_offset(value, label):
    try:
        return number(value, -3600, 3600)
    except FilterError:
        raise FilterError(label + ' must be a number between -3600 and 3600 seconds. Check Family Filters settings.')


def adjust_offset(label, current):
    value = control.dialog.input(label + ' in seconds (positive = later)', defaultt='%g' % current)
    if not value:
        raise FilterError('Timing adjustment cancelled; playback was not started')
    return parse_offset(value, label)


def align_reference(reference):
    from resources.lib.modules.family_filter_reference import show_reference
    if not reference or 'time' not in reference:
        raise FilterError('This file has no reference timestamp')
    show_reference(reference)
    actual = control.dialog.input('Matching moment in YOUR video (seconds or HH:MM:SS)')
    if not actual:
        raise FilterError('Alignment cancelled; playback was not started')
    second_reference = second_actual = None
    if control.dialog.yesno(HEADING, 'Do you have another known reference timestamp and its matching time in your video? '
                            'Use a later point to check drift. Do not guess.'):
        second_reference = control.dialog.input('Second moment in the FILTER reference timeline')
        second_actual = control.dialog.input('Same second moment in YOUR video')
        if not second_reference or not second_actual:
            raise FilterError('Second landmark check cancelled')
    return alignment_offset(reference['time'], actual, second_reference, second_actual)


def prepare(player, url):
    """Return a reviewed session, None when disabled, or raise to cancel playback."""
    if not enabled():
        return None
    audit = {'1': 'current', '2': 'all'}.get(control.setting('family.audit_next'))
    # One attempt only, including cancellation/errors. Never persist an unfiltered
    # default that could surprise the next person starting a video.
    if audit:
        control.setSetting('family.audit_next', '0')
    if player.media_type not in ('movie', 'episode'):
        raise FilterError('Open a movie or a single episode to use Family Filters')
    is_episode = player.media_type == 'episode'
    if is_episode:
        episode_number(player.season)
        episode_number(player.episode, 1)
    if player.isPlaying():
        raise FilterError('Stop the current video before starting filtered playback')
    for _ in range(20):
        if not control.homeWindow.getProperty(OWNER):
            break
        if control.monitor.waitForAbort(0.05):
            raise FilterError('Kodi is shutting down')
    else:
        raise FilterError('The previous filter session is still closing. Try again after stopping playback.')
    path = url.split('|', 1)[0]
    # Native local EDL cuts change Kodi's timeline. Do not run a second controller on top.
    if urlsplit(path).scheme not in ('http', 'https'):
        raise FilterError('This beta supports HTTP(S) streams only; local/native EDL playback is not supported here')
    control.hide()
    choices = [('import', 'Import an EDL, VideoSkip or MCF file'),
               ('subtitles', 'Silence words using SRT / WebVTT subtitles')]
    if not is_episode and control.setting('family.cleanstream') == 'true':
        choices.append(('cleanstream', 'Look up this movie on CleanStream'))
    choices.append(('videoskip', 'VideoSkip - choose a downloaded .skp file'))
    choices.append(('videoskip_online', 'VideoSkip - search online exchange'))
    preferred = {'1': 'cleanstream', '2': 'videoskip', '3': 'import', '4': 'subtitles', '5': 'videoskip_online'}.get(control.setting('family.preferred'))
    if preferred:
        if preferred not in [key for key, _ in choices]:
            raise FilterError('The preferred provider is unavailable for this title. Choose Ask, VideoSkip or Import in Family Filters settings.')
        provider = preferred
    else:
        selected = control.dialog.select(HEADING, [label for _, label in choices])
        if not isinstance(selected, int) or selected < 0 or selected >= len(choices):
            raise FilterError('Filtering cancelled; playback was not started')
        provider = choices[selected][0]
    choice = 1 if provider == 'subtitles' else 0
    if provider in ('import', 'videoskip'):
        filename = control.dialog.browseSingle(1, 'Choose a filter for ' + player.name, 'files',
                                               '.skp' if provider == 'videoskip' else '.edl|.mcf|.skp',
                                               defaultt=control.setting('family.folder'))
        if not filename:
            raise FilterError('No filter selected; playback was not started')
        data = parse_file(read_file(filename), os.path.splitext(filename)[1])
        data['metadata']['filename'] = os.path.basename(filename)
    elif provider == 'videoskip_online':
        from resources.lib.modules.family_filter_videoskip import browse
        data = browse(player)
    elif provider == 'subtitles':
        data = load_subtitles(player, url)
    elif provider == 'cleanstream':
        from resources.lib.modules.family_filter_provider import fetch_cleanstream
        xbmcvfs.mkdirs(control.dataPath)
        data = fetch_cleanstream(control.setting('family.server') or 'https://cleanstream.elfhosted.com',
                                 player.imdb, os.path.join(control.dataPath, 'family_filters.db'))
    else:
        raise FilterError('Filtering cancelled; playback was not started')
    metadata = data['metadata']
    player_meta = getattr(player, 'meta', None)
    episode_imdb = player_meta.get('episode_imdb', '') if isinstance(player_meta, dict) else ''
    release = unquote(os.path.basename(urlsplit(path).path)) or '(stream has no release filename)'
    season = player.season if is_episode else None
    episode = player.episode if is_episode else None
    validate_identity(player.media_type, player.imdb, season, episode, metadata,
                      metadata.get('filename', ''), episode_imdb)
    if is_episode:
        validate_identity('episode', player.imdb, season, episode, {}, release)
        if not control.dialog.yesno(HEADING, 'Confirm this file was made for exactly ' + player.name + '.\n'
                'Selected filter: ' + metadata.get('filename', 'Not supplied') + '\n'
                'Title/edition cannot be inferred from timestamps. Combined episodes and next-episode autoplay are not supported.'):
            raise FilterError('Episode identity was not confirmed; playback was not started')
    thresholds = {key: int(control.setting('family.' + key) or '1') for key in CATEGORIES}
    if data['source'] == 'VideoSkip import':
        # VideoSkip combines sex/nudity. Either enabled category must cover it;
        # use the more inclusive threshold and disclose this in the review.
        combined = [thresholds[key] for key in ('sex', 'nudity') if thresholds[key] > 0]
        thresholds['sex'] = min(combined) if combined else 0
    padding = float(control.setting('family.padding') or '1')
    mute = control.setting('family.mute') == 'true'
    scene_offset = parse_offset(control.setting('family.scene_offset') or '0', 'Scene offset') if choice != 1 else 0
    subtitles = data if choice == 1 else None
    if choice != 1 and control.setting('family.subtitles') == 'true':
        subtitles = load_subtitles(player, url)
        validate_identity(player.media_type, player.imdb, season, episode, subtitles['metadata'],
                          subtitles['metadata'].get('filename', ''), episode_imdb)
        if is_episode and not control.dialog.yesno(HEADING,
                'Confirm these additional subtitles belong to exactly ' + player.name + ':\n' +
                subtitles['metadata'].get('filename', 'Not supplied')):
            raise FilterError('Subtitle episode identity was not confirmed')
        if not subtitles['segments']:
            control.dialog.ok(HEADING, 'No blocked words found in these subtitles. The selected scene filters will still apply.')
    subtitle_offset = parse_offset(control.setting('family.subtitle_offset') or '0', 'Subtitle offset') if subtitles is not None else 0
    defaults = (scene_offset, subtitle_offset)
    remember = control.setting('family.remember_timing') == 'true'
    cache_path = os.path.join(control.dataPath, 'family_filters.db')
    key = timing_key(url, [player.media_type, player.imdb, player.name, season, episode], data, subtitles)
    saved = read_timing(cache_path, key) if remember else None
    if saved:
        scene_offset, subtitle_offset = saved
    timing_status = 'Saved offsets - alignment unverified' if saved else 'Unchecked'
    while True:
        offset = subtitle_offset if choice == 1 else scene_offset
        timeline = compile_timeline(data, {'language': 1} if choice == 1 else thresholds,
                                    offset, padding, True if choice == 1 else mute, allow_empty=bool(audit))
        if choice != 1 and subtitles is not None and subtitles['segments']:
            # Explicit word matches always silence, independent of scene-category settings.
            subtitle_timeline = compile_timeline(subtitles, offset=subtitle_offset, padding=padding, mute=True)
            timeline = merge_timelines(timeline, subtitle_timeline)
        rows = []
        if audit:
            rows = audit_rows(data, {'language': 1} if choice == 1 else thresholds,
                              offset, padding, True if choice == 1 else mute)
            if choice != 1 and subtitles is not None:
                rows.extend(audit_rows(subtitles, offset=subtitle_offset, padding=padding, mute=True))
            if not rows:
                raise FilterError('There are no supplied markers to audit')
        summary = [player.name, 'Selected stream: ' + release, 'Source: ' + data['source'],
                   'Filter title: ' + str(metadata.get('title', 'Not supplied')),
                   'Filter edition: ' + str(metadata.get('edition', 'Not supplied')),
                   'Author: ' + str(metadata.get('author', 'Not supplied')),
                   'Coverage notes: ' + str(metadata.get('description') or metadata.get('notes') or 'Not supplied'),
                   'Timing status: ' + timing_status,
                   'Categories represented: ' + ', '.join(sorted({row['category'] for row in data['segments']})),
                   'Category presence is not proof of complete coverage.',
                   'Padding: %.2fs' % padding,
                   'Edition and timestamp accuracy are not automatically verified.',
                   ('PARENT AUDIT: all content plays UNFILTERED. Ranges below are predictions only.' if audit else
                    'All listed ranges below will be applied. Muted ranges also hide subtitles.')]
        if audit:
            summary += ['Audit view: ' + audit, '%d supplied markers; no new content detection.' % len(rows),
                        'Current settings are snapshotted for this playback. Disabled categories remain visible in All marked content.',
                        'Next/Previous jumps to 3 seconds before an interval. Back stops playback.',
                        'Auditing does not certify timing or coverage and does not save approved timing.']
        if choice != 1:
            summary.append('Scene offset: %+.2fs' % scene_offset)
        if metadata.get('source_offsets'):
            summary.append('VideoSkip reference offsets (NOT automatically applied): ' + dumps(metadata['source_offsets'], sort_keys=True))
        if data['source'] == 'VideoSkip import':
            summary.append('VideoSkip combines sex/nudity: the more inclusive enabled threshold is used for both.')
        if metadata.get('reference'):
            summary.append('Reference landmark: %.3fs - %s' % (metadata['reference']['time'], metadata['reference']['description']))
        if subtitles is not None:
            summary.append('Subtitle offset: %+.2fs' % subtitle_offset)
            submeta = subtitles['metadata']
            summary.extend(['Subtitle source: ' + subtitles['source'],
                            'Subtitle file: ' + str(submeta.get('filename', 'Not supplied')),
                            'Subtitle edition: ' + str(submeta.get('edition', 'Not supplied')),
                            'Subtitle language: ' + str(submeta.get('language', 'Not supplied'))])
            summary.append('Subtitle word filtering silences whole caption intervals. Missing or mistimed captions can miss spoken words.')
        if 'unverified' in metadata:
            summary.append('Provider marks %s segments unverified.' % metadata['unverified'])
        summary.extend('%s %.3f - %.3f seconds' % (action.upper(), start, end)
                       for action, ranges in timeline.items() for start, end in ranges)
        control.dialog.textviewer('Review family filters', '\n'.join(summary))
        decision = control.dialog.yesnocustom(HEADING,
            ('PARENT AUDIT — UNFILTERED: scenes and words WILL play, including content your settings would block. '
             'For an adult without children watching. Banners predict filtering; they do not protect playback. Start this one audit?' if audit else
             'Use these filters for this release? Confirm their timing against your video. '
             'This beta can briefly expose content during startup or seeking and is not a guaranteed child-safety control.'),
            customlabel='Adjust timing', nolabel='Cancel', yeslabel='Start unfiltered audit' if audit else 'Use filters')
        if decision == 1:
            if audit:
                alignment = dict(reference=metadata.get('reference'), cache_path=cache_path, key=key,
                                 scene_offset=scene_offset, subtitle_offset=subtitle_offset, data=data, padding=padding)
                return AuditSession(player, timeline, path, rows, audit, alignment)
            if remember:
                xbmcvfs.mkdirs(control.dataPath)
                if not save_timing(cache_path, key, scene_offset, subtitle_offset):
                    control.dialog.ok(HEADING, 'Filters are ready, but timing could not be saved. It will need checking again next time.')
            return Session(player, timeline, path, review_text='\n'.join(summary))
        if decision != 2:
            raise FilterError('Filter review cancelled; playback was not started')
        # Never overwrite global defaults. Re-review every adjusted timeline.
        if metadata.get('reference') or saved:
            actions = ['Enter offsets manually']
            if metadata.get('reference'):
                actions.append('View reference and calculate offset from a measured timestamp')
            if saved:
                actions.append('Forget this saved timing and use defaults')
            action = control.dialog.select('Timing tools', actions)
            if action < 0:
                raise FilterError('Timing adjustment cancelled')
            if metadata.get('reference') and action == 1:
                scene_offset = align_reference(metadata['reference'])
                timing_status = 'Manually aligned reference - not full-video verification'
                continue
            if saved and action == len(actions) - 1:
                if not forget_timing(cache_path, key):
                    raise FilterError('Could not forget the saved timing')
                scene_offset, subtitle_offset = defaults
                saved, remember = None, False
                timing_status = 'Unchecked'
                continue
        if choice != 1:
            scene_offset = adjust_offset('Scene offset', scene_offset)
        if subtitles is not None and subtitles['segments']:
            subtitle_offset = adjust_offset('Subtitle offset', subtitle_offset)
        timing_status = 'Manually entered offsets - alignment unverified'


class Backend:
    def __init__(self, player):
        self.player = player

    def seek(self, seconds):
        self.player.seekTime(seconds)

    def stop(self):
        self.player.stop()

    def muted(self):
        response = loads(xbmc.executeJSONRPC(dumps({'jsonrpc': '2.0', 'id': 1,
            'method': 'Application.GetProperties', 'params': {'properties': ['muted']}})))
        return response['result']['muted']

    def set_muted(self, muted):
        # An explicit boolean avoids toggling a user's pre-existing mute state.
        response = loads(xbmc.executeJSONRPC(dumps({'jsonrpc': '2.0', 'id': 1,
            'method': 'Application.SetMute', 'params': {'mute': bool(muted)}})))
        if 'error' in response:
            raise FilterError('Unable to control audio muting')

    def subtitles(self):
        return bool(xbmc.getCondVisibility('VideoPlayer.SubtitlesEnabled'))

    def set_subtitles(self, visible):
        if self.player.isPlayingVideo():
            self.player.showSubtitles(bool(visible))


class Session:
    def __init__(self, player, timeline, expected_path, engine=None, review_text=''):
        self.player, self.timeline, self.expected_path = player, timeline, expected_path
        self.engine = engine if engine is not None else PlaybackFilter(timeline, Backend(player))
        self.token = uuid.uuid4().hex
        self.lock, self.done = RLock(), Event()
        self.thread = None
        self.path = None
        self.controls = PlaybackControls(self, review_text) if engine is None else None

    def safe_resume(self, position):
        return skip_target(self.timeline, float(position)) or position

    def start(self):
        with self.lock:
            if self.thread or self.done.is_set():
                return
            self.path = self.player.getPlayingFile()
            if self.path.split('|', 1)[0] != self.expected_path:
                raise FilterError('Player stream identity changed; filters could not be attached')
            control.homeWindow.setProperty(OWNER, self.token)
            self.thread = Thread(target=self._run)
            self.thread.daemon = True
            self.thread.start()

    def _run(self):
        failure = None
        try:
            while not self.done.is_set() and not control.monitor.abortRequested():
                with self.lock:
                    if control.homeWindow.getProperty(OWNER) != self.token:
                        break
                    if not self.player.isPlaying():
                        break
                    if self.player.getPlayingFile() != self.path:
                        raise FilterError('The stream changed during filtered playback')
                    position, duration, now = self.player.getTime(), self.player.getTotalTime(), time.monotonic()
                    self.engine.tick(position, duration, now)
                    if self.controls:
                        self.controls.tick(position, now)
                self.done.wait(0.05)
        except Exception as exc:
            failure = str(exc) if isinstance(exc, FilterError) else 'Playback filtering failed'
            try:
                if control.homeWindow.getProperty(OWNER) == self.token:
                    self.player.stop()
            except Exception:
                pass
        finally:
            self.close()
        if failure:
            control.dialog.ok(HEADING, failure + '. Playback stopped.')

    def close(self):
        self.done.set()
        with self.lock:
            if self.controls:
                self.controls.close()
            if control.homeWindow.getProperty(OWNER) == self.token:
                try:
                    self.engine.close()
                except Exception:
                    # Playback may have already ended; audio restoration is attempted
                    # before subtitle restoration, which can fail after EOF.
                    from resources.lib.modules import log_utils
                    log_utils.log('Family Filters: could not restore playback controls', level=log_utils.LOGWARNING)
                finally:
                    control.homeWindow.clearProperty(OWNER)
        if self.thread and self.thread is not current_thread():
            self.thread.join(1)


class PlaybackControls:
    """Optional OSD companion. Hiding/failing UI never disables filtering."""
    def __init__(self, session, review_text):
        self.session, self.review_text = session, review_text
        self.window = None
        self.osd_visible = False
        self.disabled = False
        self.opened_at = 0
        self.native_until = 0
        self.pending_seek = None

        rows = [dict(start=start, end=end, action=action)
                for action, ranges in session.timeline.items() for start, end in ranges]
        self.navigation = AuditModel(rows, session.timeline, 'current')

    def close(self):
        if self.window:
            self.window.close()
            self.window = None

    def tick(self, position=None, now=None):
        if self.disabled:
            return
        try:
            if now is None:
                now = time.monotonic()
            visible = bool(xbmc.getCondVisibility('Window.IsVisible(videoosd)'))
            opening = visible and not self.osd_visible
            self.osd_visible = visible
            if self.window and self.window.closed.is_set():
                if self.window.failed:
                    raise FilterError('Playback controls could not open')
                self.window = None
                return
            if self.window is None and opening and now >= self.native_until:
                from resources.lib.modules.family_filter_playback_ui import create_controls
                self.window = create_controls(self.command)
                self.opened_at = now
            if self.window:
                if not self.window.ready and now - self.opened_at > 5:
                    raise FilterError('Playback controls did not open')
                if position is None:
                    position = self.session.player.getTime()
                timeline = self.session.timeline
                selected = next((action.upper() for action in ('skip', 'mute')
                    if any(start <= position < end for start, end in timeline[action])), 'No selected interval here')
                self.window.setProperty('family.playback.status',
                    'FAMILY FILTERS ON | %d skip / %d mute intervals | Timing / coverage unverified\nSelected action: %s' %
                    (len(timeline['skip']), len(timeline['mute']), selected))
        except Exception:
            # Controls are supplementary; filtering must keep running even if
            # the skin/UI is unavailable. Do not open a blocking error dialog.
            self.close()
            self.disabled = True
            control.notification(title='Family Filters', message='Playback controls unavailable; filtering remains active')

    def command(self, action):
        session = self.session
        details = None
        try:
            with session.lock:
                if session.done.is_set() or control.homeWindow.getProperty(OWNER) != session.token:
                    return
                if not session.player.isPlayingVideo() or session.player.getPlayingFile() != session.path:
                    return
                if action == 'stop':
                    session.player.stop()
                    session.done.set()
                elif action == 'pause':
                    session.player.pause()
                elif action == 'play':
                    if xbmc.getCondVisibility('Player.Paused'):
                        session.player.pause()
                elif action in ('dismiss', 'native'):
                    self.close()
                    if action == 'dismiss':
                        control.execute('Dialog.Close(videoosd)')
                    else:
                        # Kodi may have timed out its underlying OSD while this
                        # panel was open. Reopen it without immediately taking
                        # focus back during the asynchronous window transition.
                        self.native_until = time.monotonic() + 1
                        self.osd_visible = True
                        control.execute('ActivateWindow(videoosd)')
                elif action == 'details':
                    details = ('FAMILY FILTERS ON — playback continues with the reviewed filters.\n'
                        'Timing and coverage are unverified. Settings are a snapshot for this playback.\n'
                        'To change categories or timing, stop and restart through filter review.\n'
                        'For landmark calibration, arm Parent Audit for the next playback; it is UNFILTERED.\n\n' +
                        self.review_text)
                elif action in ('back', 'forward', 'next_filter'):
                    now = time.monotonic()
                    position = number(session.player.getTime(), -1)
                    if self.pending_seek and now < self.pending_seek[1]:
                        position = self.pending_seek[0]
                    duration = number(session.player.getTotalTime(), 0.001)
                    if action == 'next_filter':
                        target = self.navigation.navigate(1, position)
                        if target is None:
                            control.notification(title='Family Filters', message='No later selected interval')
                            return
                    else:
                        self.navigation.navigation = None
                        target = max(0, min(duration - 0.1, position + (-10 if action == 'back' else 30)))
                    # Never deliberately land inside an interval selected to skip.
                    target = session.safe_resume(target)
                    if target >= duration:
                        session.player.stop()
                        session.done.set()
                    else:
                        session.player.seekTime(target)
                        self.pending_seek = (target, now + 2)
            if details is not None:
                control.dialog.textviewer('Family Filters - review / timing', details)
        except Exception:
            # Do not change the filter engine or global mute state on UI errors.
            self.close()


class AuditController:
    def __init__(self, rows, timeline, mode):
        self.model = AuditModel(rows, timeline, mode)
        self.window = None
        self.command = None
        self.can_align = False
        self.can_mark = False
        self.alignment_status = ''
        self.last_banner = None

    def tick(self, position, duration, now):
        self.model.tick(position, duration, now)
        if self.window is None:
            from resources.lib.modules.family_filter_audit_ui import create_overlay
            self.window = create_overlay(self.command)
        if not self.window.ready:
            if now - self.model.started_at > 5:
                raise FilterError('Parent audit overlay did not open')
        elif not xbmc.getCondVisibility('Window.IsVisible(%d)' % self.window.window_id):
            raise FilterError('Parent audit overlay closed')
        heading = 'PARENT AUDIT - UNFILTERED | %s | Timing / coverage unverified' % (
            'All marked content' if self.model.mode == 'all' else 'Current settings')
        if self.alignment_status:
            heading = 'TIMING SETUP - UNFILTERED | ' + self.alignment_status
        text = self.model.banner()
        active = bool(self.model.active())
        banner = (heading, text, active)
        if banner != self.last_banner:
            self.window.setProperty('family.audit.can_align', 'true' if self.can_align else '')
            self.window.setProperty('family.audit.can_mark', 'true' if self.can_mark else '')
            self.window.setProperty('family.audit.heading', heading)
            self.window.setProperty('family.audit.text', text)
            self.window.setProperty('family.audit.active', 'true' if active else '')
            self.last_banner = banner

    def close(self):
        if self.window is not None:
            self.window.close()
            self.window = None


class AuditSession(Session):
    def __init__(self, player, timeline, expected_path, rows, mode, alignment=None):
        super().__init__(player, timeline, expected_path, AuditController(rows, timeline, mode))
        self.engine.command = self.command
        self.pending_seek = None
        self.alignment = alignment or {}
        self.engine.can_align = bool(self.alignment.get('reference', {}).get('image')) if self.alignment.get('reference') else False
        self.engine.can_mark = bool(self.alignment.get('reference')) and self.alignment['reference'].get('time') is not None
        self.aligning = False
        self.alignment_thread = None

    def safe_resume(self, position):
        # Audit must not skip a blocked interval while applying a resume bookmark.
        return position

    def close(self):
        super().close()
        # Unlike audio restoration, removing our own overlay is safe even if a
        # newer session owns playback. Never leave stale remote controls behind.
        with self.lock:
            self.engine.close()

    def command(self, action):
        details = None
        align = False
        manual = None
        try:
            with self.lock:
                if self.done.is_set() or control.homeWindow.getProperty(OWNER) != self.token:
                    return
                if not self.player.isPlayingVideo() or self.player.getPlayingFile() != self.path:
                    raise FilterError('The audit stream changed')
                model = self.engine.model
                if self.aligning and action != 'stop':
                    return
                if action == 'stop':
                    self.player.stop()
                    self.done.set()
                elif action == 'pause':
                    self.player.pause()
                elif action == 'view':
                    model.toggle()
                    self.pending_seek = None
                elif action == 'play':
                    if xbmc.getCondVisibility('Player.Paused'):
                        self.player.pause()
                elif action == 'details':
                    details = model.details()
                elif action == 'align' and self.engine.can_align:
                    align = True
                elif action in ('reference', 'reference_seek', 'back_second', 'forward_second', 'mark') and self.engine.can_mark:
                    manual = action
                elif action in ('next', 'previous'):
                    now = time.monotonic()
                    position = self.player.getTime()
                    if self.pending_seek and now < self.pending_seek[1]:
                        position = self.pending_seek[0]
                    target = model.navigate(1 if action == 'next' else -1, position)
                    if target is not None:
                        self.player.seekTime(target)
                        self.pending_seek = (target, now + 2)
                    else:
                        control.notification(title='Parent audit', message='No %s marked interval in this view' % action)
            # Do not block the monitor lock while a parent reads the dialog.
            if details is not None:
                control.dialog.textviewer('Parent audit - current markers', details)
            if manual:
                self._manual_timing(manual)
            if align and control.dialog.yesno('Auto-align - adult setup',
                    'Search 10 seconds either side of the reference plus your current offset? '
                    'Original picture and audio WILL play. Playback stops when done. '
                    'This experimental image matcher only proposes an offset; it cannot verify the whole video. '
                    'Back/Stop cancels. Do this without children watching.'):
                with self.lock:
                    if self.done.is_set() or self.aligning or control.homeWindow.getProperty(OWNER) != self.token:
                        return
                    self.aligning = True
                    self.engine.alignment_status = 'Starting bounded reference search'
                    self.alignment_thread = Thread(target=self._align)
                    self.alignment_thread.daemon = True
                    self.alignment_thread.start()
        except Exception:
            if control.homeWindow.getProperty(OWNER) == self.token:
                self.player.stop()
                self.done.set()

    def _check_manual(self):
        if (self.done.is_set() or control.monitor.abortRequested() or
                control.homeWindow.getProperty(OWNER) != self.token or
                not self.player.isPlayingVideo() or self.player.getPlayingFile() != self.path):
            raise FilterError('Timing setup cancelled or playback changed')

    def _manual_timing(self, action):
        """Adult-observed landmark, without frame capture or audio changes."""
        try:
            with self.lock:
                self._check_manual()
                reference = self.alignment['reference']
                reference_time = number(reference['time'])
                duration = number(self.player.getTotalTime(), 0.001)
                if action == 'reference':
                    if not xbmc.getCondVisibility('Player.Paused'):
                        self.player.pause()
                elif action in ('reference_seek', 'back_second', 'forward_second'):
                    position = number(self.player.getTime())
                    if action == 'reference_seek':
                        target = reference_time + self.alignment['scene_offset'] - 3
                    else:
                        if self.pending_seek and time.monotonic() < self.pending_seek[1]:
                            position = self.pending_seek[0]
                        target = position + (-1 if action == 'back_second' else 1)
                    target = max(0, min(duration - 0.1, target))
                    self.player.seekTime(target)
                    self.pending_seek = (target, time.monotonic() + 2)
                    self.engine.alignment_status = 'Seek requested: %.3fs. Pause on the matching landmark, then Mark reference.' % target
                    return
                elif action == 'mark':
                    if not xbmc.getCondVisibility('Player.Paused'):
                        raise FilterError('Pause on the matching reference first; then choose Mark reference')
                    if self.pending_seek and time.monotonic() < self.pending_seek[1]:
                        raise FilterError('Wait for the seek to settle before marking the reference')
                    actual = number(self.player.getTime(), 0, duration)
            if action == 'reference':
                from resources.lib.modules.family_filter_reference import show_reference
                show_reference(reference, 'Parent timing setup - UNFILTERED. Reference: %.3fs.\n%s\n\n'
                    'Find this exact landmark in your video. Close this preview, use Go to reference and '
                    'the one-second seek buttons, then Pause / resume to pause on the matching frame. '
                    'Mark reference proposes an offset; it does not verify synchronization. '
                    'Closing this preview does not resume playback.' %
                    (reference_time, str(reference.get('description', ''))))
                return
            # A paused clock must stay stable after decoder seeks have settled.
            self.done.wait(0.25)
            with self.lock:
                self._check_manual()
                if (not xbmc.getCondVisibility('Player.Paused') or
                        abs(number(self.player.getTime(), 0, duration) - actual) > 0.05):
                    raise FilterError('Playback position changed; pause and mark the reference again')
                offset = alignment_offset(reference_time, actual)
                rows = audit_rows(self.alignment['data'], offset=offset, padding=self.alignment['padding'])
                if any(row['end'] > duration for row in rows):
                    raise FilterError('Proposed alignment moves filters beyond the video')
                self.player.stop()
            self.close()
            if control.homeWindow.getProperty(OWNER):
                return
            if not control.dialog.yesno('Save manually marked timing?',
                    'Reference %.3fs; your paused position %.3fs; proposed scene offset %+.3fs. '
                    'Playback has stopped. Save for this exact stream/filter and enable remembered timing? '
                    'Subtitle timing and global defaults stay unchanged. A single landmark cannot verify drift, '
                    'decoder accuracy, or different editions. Restart the same source and audit a later scene '
                    'before family use.' % (reference_time, actual, offset)):
                return
            # A new playback/session while the dialog was open invalidates this action.
            if control.homeWindow.getProperty(OWNER) or self.player.isPlaying() or control.monitor.abortRequested():
                return
            if not save_timing(self.alignment['cache_path'], self.alignment['key'], offset, self.alignment['subtitle_offset']):
                raise FilterError('Could not save the proposed timing')
            control.setSetting('family.remember_timing', 'true')
            control.dialog.ok('Manual timing saved', 'Restart the same source and audit the result, including a later scene. '
                              'This is a parent-selected offset, not verified synchronization.')
        except FilterError as exc:
            # Invalid marks and cancelled previews leave the audit unchanged.
            if control.homeWindow.getProperty(OWNER) in ('', self.token):
                control.dialog.ok('Manual timing not saved', str(exc))

    def _align(self):
        from resources.lib.modules.family_filter_alignment import scan
        result, failure = None, None
        def check():
            if (self.done.is_set() or control.monitor.abortRequested() or
                    control.homeWindow.getProperty(OWNER) != self.token or
                    not self.player.isPlayingVideo() or self.player.getPlayingFile() != self.path):
                raise FilterError('Alignment cancelled or playback changed')
        def wait(seconds):
            self.done.wait(seconds)
            check()
        def progress(message):
            self.engine.alignment_status = message
        try:
            result = scan(self.player, self.alignment['reference'], self.alignment['scene_offset'], check, wait,
                          xbmc.RenderCapture, lambda: xbmc.getCondVisibility('Player.Paused'), progress)
            check()
            proposed = audit_rows(self.alignment['data'], offset=result['offset'], padding=self.alignment['padding'])
            if any(row['end'] > self.player.getTotalTime() for row in proposed):
                raise FilterError('Proposed alignment moves filters beyond the video')
        except Exception as exc:
            failure = str(exc) if isinstance(exc, FilterError) else 'Automatic alignment failed; use manual timing'
        # Never stop or alter a newer session. User cancellation produces no prompt.
        with self.lock:
            if self.done.is_set() or control.homeWindow.getProperty(OWNER) != self.token:
                return
            self.player.stop()
        self.close()
        if control.homeWindow.getProperty(OWNER):
            return
        if failure:
            control.dialog.ok('Auto-align did not find a usable match', failure + '. No timing was saved. Playback stopped.')
            return
        try:
            from resources.lib.modules.family_filter_reference import show_reference
            instructions = ('LEFT: provider reference. RIGHT: proposed matching video frame.\n'
                'Reference: %.3fs; captured candidate: %.3fs; proposed offset: %+.3fs.\n\n'
                'Inspect BOTH images. Similar frames or decoder latency can give a wrong timestamp. '
                'A single point cannot verify drift or edition changes. Continue only to review the save prompt; '
                'Back rejects this proposal. Playback has stopped.' %
                (self.alignment['reference']['time'], result['actual'], result['offset']))
            show_reference({'image': result['preview'], 'time': result['actual'], 'description': ''}, instructions)
            if not control.dialog.yesno('Save proposed timing?',
                    'Save scene offset %+.3fs for this exact stream/filter and enable remembered timing? '
                    'Subtitle timing stays unchanged. Restart the same source and audit the result, including a later scene. '
                    'This is an adult-accepted candidate, NOT verified synchronization.' % result['offset']):
                return
            if not save_timing(self.alignment['cache_path'], self.alignment['key'], result['offset'], self.alignment['subtitle_offset']):
                raise FilterError('Could not save the proposed timing')
            control.setSetting('family.remember_timing', 'true')
            control.dialog.ok('Timing proposal saved', 'Restart the same source and review/audit before family use. '
                              'A changed signed stream URL will not reuse this proposal. Global timing defaults were not changed.')
        except FilterError as exc:
            control.dialog.ok('Timing proposal not saved', str(exc))
