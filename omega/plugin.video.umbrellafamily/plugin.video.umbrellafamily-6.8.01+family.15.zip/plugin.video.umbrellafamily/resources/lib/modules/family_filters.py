# -*- coding: utf-8 -*-
"""Family filter formats and timeline logic. No Kodi dependency.

All positions use the original, uncut media timeline, in seconds.
Malformed input invalidates the entire filter; partial parsing is not acceptable.
"""

import json
import math
import re
import unicodedata

MAX_BYTES = 2 * 1024 * 1024
MAX_SEGMENTS = 10000
MAX_SECONDS = 24 * 60 * 60
STARTUP_TIMING_GRACE = 5.0
MAX_STARTUP_PREROLL = 1.0
MAX_SEEK_ATTEMPTS = 3
SEEK_RETRY_STEP = 0.5
SEEK_CLEARANCE = 2.0
CATEGORIES = ('nudity', 'sex', 'violence', 'language', 'drugs', 'fear', 'other')
LEVELS = {'low': 1, 'medium': 2, 'high': 3}
MCF_GROUPS = {
    'nudity': 'bareButtocks exposedGenitalia fullNudity toplessness',
    'sex': 'adultery analSex coitus kissing masturbation objectification oralSex premaritalSex promiscuity prostitution',
    'violence': 'choking crueltyToAnimals culturalViolence desecration emotionalViolence kicking massacre murder punching rape slapping slavery stabbing torture warfare weapons',
    'language': 'blasphemy nameCalling sexualDialogue swearing vulgarity',
    'drugs': 'alcohol antipsychotics cigarettes depressants gambling hallucinogens stimulants',
    'fear': 'accident acrophobia aliens arachnophobia claustrophobia death explosion fire ghosts vampires',
}
MCF_CATEGORIES = {category: group for group, categories in MCF_GROUPS.items() for category in categories.split()}


class FilterError(ValueError):
    pass


def number(value, minimum=0, maximum=MAX_SECONDS):
    if isinstance(value, bool):
        raise FilterError('Boolean timestamp')
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        raise FilterError('Invalid number')
    if not math.isfinite(result) or not minimum <= result <= maximum:
        raise FilterError('Number outside supported range')
    return result


def timestamp(value, fps=None):
    value = str(value).strip().replace(',', '.')
    if value.startswith('#'):
        if fps is None:
            raise FilterError('Frame-based EDL needs a known frame rate; convert it to seconds first')
        return number(value[1:], maximum=MAX_SECONDS * 240) / number(fps, 1, 240)
    parts = value.split(':')
    if len(parts) == 1:
        return number(value)
    if len(parts) not in (2, 3) or not all(re.fullmatch(r'\d+', x) for x in parts[:-1]):
        raise FilterError('Invalid timecode')
    seconds = number(parts[-1], maximum=59.999999)
    minutes = number(parts[-2], maximum=59 if len(parts) == 3 else 1439)
    hours = number(parts[0], maximum=23) if len(parts) == 3 else 0
    return number(hours * 3600 + minutes * 60 + seconds)


def segment(start, end, action='skip', category='other', severity=None, label=''):
    start, end = number(start), number(end)
    if end <= start or action not in ('skip', 'mute'):
        raise FilterError('Invalid segment range or action')
    if severity is not None and severity not in LEVELS:
        raise FilterError('Unknown severity')
    return dict(start=start, end=end, action=action,
                category=category if category in CATEGORIES else 'other',
                severity=severity, label=str(label)[:500])


def document(segments, source, **metadata):
    if not segments or len(segments) > MAX_SEGMENTS:
        raise FilterError('No usable filters, or too many segments')
    return dict(segments=segments, source=source, metadata=metadata)


def parse_edl(text, fps=None):
    segments = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith('##'):
            continue
        parts = line.split()
        if len(parts) == 2 and parts[1] == '2':
            timestamp(parts[0], fps)  # Scene markers are not filters.
            continue
        if len(parts) != 3 or parts[2] not in ('0', '1', '2', '3'):
            raise FilterError('Expected: start end action (0/1/2/3)')
        start, end = timestamp(parts[0], fps), timestamp(parts[1], fps)
        if parts[2] == '2':
            continue
        if parts[1].startswith('#'):
            end += 1 / number(fps, 1, 240)  # Kodi frame endpoints are inclusive.
        segments.append(segment(start, end, 'mute' if parts[2] == '1' else 'skip'))
    return document(segments, 'Local EDL', edition='Not supplied')


def parse_mcf(text):
    blocks = re.split(r'\n\s*\n', text.replace('\r\n', '\n').strip())
    if blocks.pop(0) not in ('WEBVTT MovieContentFilter 1.0.0', 'WEBVTT MovieContentFilter 1.1.0'):
        raise FilterError('Unsupported MovieContentFilter header/version')
    metadata, segments = {}, []
    for block in blocks:
        lines = block.splitlines()
        if lines[0] == 'NOTE':
            for line in lines[1:]:
                key, sep, value = line.partition(' ')
                if not sep:
                    raise FilterError('Invalid MCF metadata')
                metadata[key.lower()] = value
            continue
        if '-->' not in lines[0] and len(lines) > 1:
            lines.pop(0)  # Optional WebVTT cue identifier.
        times = lines.pop(0).split('-->')
        if len(times) != 2 or not lines:
            raise FilterError('Invalid MCF cue')
        start, end = [timestamp(x) for x in times]
        for line in lines:
            fields = line.split(' # ', 1)[0].strip().split('=')
            if len(fields) not in (2, 3):
                raise FilterError('Invalid MCF category/severity/channel')
            category, severity = fields[:2]
            channel = fields[2] if len(fields) == 3 else 'both'
            if not category or channel not in ('both', 'audio', 'video'):
                raise FilterError('Invalid MCF channel')
            # Preserve unfamiliar subcategories as Other rather than guessing or dropping them.
            segments.append(segment(start, end, 'mute' if channel == 'audio' else 'skip',
                                    MCF_CATEGORIES.get(category, category), severity, line))
    if metadata.get('type', 'movie') not in ('movie', 'episode'):
        raise FilterError('Unsupported filter media type')
    metadata['edition'] = metadata.get('release', 'Not supplied')
    return document(segments, 'MovieContentFilter import', **metadata)


def parse_skp(text):
    """Import VideoSkip cues and retain, but do not assume, source offsets.

    Video-only/blur/fast-forward instructions become skips. Unrecognized cue
    labels remain Other. A Kodi stream is not necessarily the author's local file.
    """
    body = text.split('data:image/', 1)[0].strip()
    offsets, reference = {}, {}
    json_start = re.search(r'(?m)^\s*\{', body)
    if json_start:
        try:
            offsets = json.loads(body[json_start.start():])
            if not isinstance(offsets, dict) or len(offsets) > 100:
                raise ValueError('Invalid offsets')
            offsets = {str(key)[:100]: number(value, -3600, 3600) for key, value in offsets.items()}
        except (ValueError, TypeError, AttributeError):
            raise FilterError('Invalid VideoSkip source offsets')
        body = body[:json_start.start()].strip()
    segments = []
    for block in re.split(r'\n\s*\n', body.replace('\r\n', '\n')):
        lines = block.strip().splitlines()
        time_lines = [i for i, line in enumerate(lines) if '-->' in line]
        if not time_lines:
            # VideoSkip begins with a synchronization time and description.
            if segments:
                raise FilterError('Unexpected VideoSkip block')
            if len(lines) >= 2 and not reference:
                reference = {'time': timestamp(lines[0]), 'description': ' '.join(lines[1:])[:1000]}
            continue
        if len(time_lines) != 1:
            raise FilterError('Invalid VideoSkip cue')
        index = time_lines[0]
        times = lines[index].split('-->')
        label = ' '.join(lines[index + 1:]).strip()
        if len(times) != 2 or not label:
            raise FilterError('Invalid VideoSkip timing or label')
        start, end = [timestamp(x) for x in times]
        if '//' in label:
            continue  # Explicitly disabled by the file author.
        plain = re.sub(r'\(.*?\)', '', label.lower())
        # Blur rectangle coordinates are not category severity levels.
        plain = re.sub(r'\[[^\]]*\]', '', plain)
        category = 'other'
        for pattern, name in ((r'sex|nud', 'sex'), (r'vio|gor', 'violence'),
                              (r'pro|cur|hat', 'language'), (r'alc|dru|smo', 'drugs'),
                              (r'fri|sca|int', 'fear')):
            if re.search(pattern, plain):
                category = name
                break
        grade = re.search(r'\d', plain)
        severity = {1: 'low', 2: 'medium', 3: 'high'}.get(min(3, int(grade[0]))) if grade else None
        # A visual blur request must not degrade to audio-only muting when
        # both instructions occur in a cue. We implement blur as a full skip.
        action = 'mute' if not re.search(r'\bblu\w*\b', plain) and re.search(r'aud|sou|spe|wor|mut', plain) else 'skip'
        segments.append(segment(start, end, action, category, severity, label))
    if 'data:image/' in text and reference:
        reference['image'] = 'data:image/' + text.split('data:image/', 1)[1].strip()
    return document(segments, 'VideoSkip import', edition='Confirm against the original skip file',
                    source_offsets=offsets, reference=reference)


def parse_file(text, extension):
    if len(text.encode('utf-8')) > MAX_BYTES:
        raise FilterError('Filter file exceeds 2 MiB')
    parsers = {'.edl': parse_edl, '.mcf': parse_mcf, '.skp': parse_skp}
    if extension.lower() not in parsers:
        raise FilterError('Choose an .edl, .mcf or .skp file')
    result = parsers[extension.lower()](text.lstrip('\ufeff'))
    from hashlib import sha256
    result['metadata']['fingerprint'] = sha256(text.encode('utf-8')).hexdigest()
    return result


def subtitle_vocabulary(words):
    vocabulary = [' '.join(unicodedata.normalize('NFKC', word).casefold().split())
                  for word in words.split(',') if word.strip()]
    if not vocabulary or len(vocabulary) > 500 or any(len(word) > 100 for word in vocabulary):
        raise FilterError('Enter between 1 and 500 comma-separated words or phrases')
    return vocabulary


def subtitle_mutes(text, words):
    """Mute entire matching SRT/WebVTT cues; these are not word-level timings.

    Match literal words/phrases, ignoring case and markup. No stemming or regex
    from settings: 'hell' must not match 'hello', and 'ass' must not match 'class'.
    """
    if len(text.encode('utf-8')) > MAX_BYTES:
        raise FilterError('Subtitle file exceeds 2 MiB')
    vocabulary = subtitle_vocabulary(words)
    pattern = re.compile(r'(?<!\w)(?:' + '|'.join(re.escape(word) for word in vocabulary) + r')(?!\w)')
    segments = []
    cue_count = 0
    matched_terms = set()
    text = text.lstrip('\ufeff').replace('\r\n', '\n').strip()
    is_vtt = text.startswith('WEBVTT')
    if is_vtt and 'X-TIMESTAMP-MAP' in text:
        raise FilterError('Segmented WebVTT timestamp maps are not supported; export a full-video subtitle file')
    blocks = re.split(r'\n\s*\n', text)
    if is_vtt:
        header = blocks.pop(0).splitlines()
        if not re.fullmatch(r'WEBVTT(?:[ \t].*)?', header[0]) or any('-->' in line for line in header):
            raise FilterError('Invalid WebVTT header')
    for block in blocks:
        lines = block.splitlines()
        if is_vtt and lines and (lines[0] in ('STYLE', 'REGION', 'NOTE') or lines[0].startswith(('NOTE ', 'NOTE\t'))):
            continue
        if lines and (lines[0].strip().isdigit() or (is_vtt and '-->' not in lines[0])):
            lines.pop(0)
        if len(lines) < 2:
            raise FilterError('Invalid SRT cue')
        times = lines.pop(0).split('-->')
        if len(times) != 2:
            raise FilterError('Invalid SRT timing')
        if is_vtt:
            fields = times[1].strip().split()
            if not fields:
                raise FilterError('Invalid WebVTT end time')
            times[1] = fields[0]  # WebVTT positioning settings do not change timing.
        start, end = [timestamp(x.strip()) for x in times]
        row = segment(start, end, 'mute', 'language', label='Subtitle word match')
        from html import unescape
        caption = unescape(re.sub(r'<[^>]*>|\{[^}]*\}', '', ' '.join(lines)))
        caption = ' '.join(unicodedata.normalize('NFKC', caption).casefold().split())
        cue_count += 1
        matches = list(pattern.finditer(caption))
        if matches:
            matched_terms.update(match.group(0) for match in matches)
            segments.append(row)
    if len(segments) > MAX_SEGMENTS:
        raise FilterError('Too many matching subtitle cues')
    # No matches means no detected words, not that the movie has been reviewed.
    from hashlib import sha256
    return dict(segments=segments, source='Subtitle word filter', metadata={
        'edition': 'Match the subtitles to your release', 'format': 'WebVTT' if is_vtt else 'SRT',
        'fingerprint': sha256(text.encode('utf-8')).hexdigest(), 'cue_count': cue_count,
        'word_count': len(vocabulary), 'matched_term_count': len(matched_terms)})


def merge_timelines(*timelines):
    rows = [segment(start, end, action) for timeline in timelines
            for action, ranges in timeline.items() for start, end in ranges]
    return compile_timeline(document(rows, 'Combined'), padding=0, mute=True)


def parse_cleanstream(data, imdb):
    if not isinstance(data, dict) or data.get('imdbId') != imdb or data.get('type') != 'movie':
        raise FilterError('Provider returned a different title or media type')
    rows = data.get('segments')
    if not isinstance(rows, list) or len(rows) > MAX_SEGMENTS:
        raise FilterError('Invalid provider segment list')
    segments = []
    for row in rows:
        if not isinstance(row, dict) or row.get('channel', 'both') not in ('both', 'audio', 'video'):
            raise FilterError('Invalid provider segment')
        start = number(row.get('startMs'), maximum=MAX_SECONDS * 1000) / 1000
        end = number(row.get('endMs'), maximum=MAX_SECONDS * 1000) / 1000
        segments.append(segment(start, end, 'mute' if row.get('channel') == 'audio' else 'skip',
                                row.get('category', 'other'), row.get('severity'), row.get('comment', '')))
    return document(segments, 'CleanStream', imdb=imdb, title=data.get('title', ''),
                    edition='Not automatically matched', revision=data.get('updatedAt', ''),
                    unverified=sum(row.get('verified') is not True for row in rows))


def rule_action(row, thresholds=None, mute=False):
    threshold = int((thresholds or {}).get(row['category'], 1))
    if threshold == 0 or (row['severity'] is not None and LEVELS[row['severity']] < threshold):
        return None
    return row['action'] if mute else 'skip'


def compile_timeline(data, thresholds=None, offset=0, padding=0.5, mute=False, allow_empty=False):
    offset, padding = number(offset, -3600, 3600), number(padding, 0, 10)
    thresholds = thresholds or {}
    actions = {'skip': [], 'mute': []}
    for row in data['segments']:
        action = rule_action(row, thresholds, mute)
        if action is None:
            continue
        start, end = row['start'] + offset - padding, row['end'] + offset + padding
        if end <= 0:
            raise FilterError('Timing adjustment moves a filter before the video')
        actions[action].append((max(0, start), number(end)))
    # Merge each action separately; skip takes precedence over mute at evaluation.
    for action, ranges in actions.items():
        merged = []
        for start, end in sorted(ranges):
            if merged and start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(end, merged[-1][1]))
            else:
                merged.append((start, end))
        actions[action] = merged
    if not allow_empty and not any(actions.values()):
        raise FilterError('These preferences select no filters; playback was not started')
    return actions


def skip_target(timeline, position):
    for start, end in timeline['skip']:
        if start <= position < end:
            return end
    return None


class PlaybackFilter:
    """Tick-driven controller. The host serializes ticks and owns session identity.

    backend supplies seek, stop, muted, set_muted, subtitles, set_subtitles.
    A seek must be observed outside its range within two seconds of wall time.
    """
    def __init__(self, timeline, backend):
        self.timeline, self.backend = timeline, backend
        self.pending = None
        self.seek_guard = None
        self.saved_audio = None
        self.saved_subtitles = None
        self.closed = False
        self.started_at = None
        self.duration_ready = False

    def _mute(self, active):
        if active:
            if self.saved_audio is None:
                self.saved_audio = self.backend.muted()
                self.saved_subtitles = self.backend.subtitles()
            self.backend.set_muted(True)
            self.backend.set_subtitles(False)
        elif self.saved_audio is not None:
            self.backend.set_muted(self.saved_audio)
            self.backend.set_subtitles(self.saved_subtitles)
            self.saved_audio = self.saved_subtitles = None

    def tick(self, position, duration, now):
        if self.closed:
            return
        if self.started_at is None:
            self.started_at = now
        try:
            position = number(position, minimum=-MAX_STARTUP_PREROLL)
        except FilterError:
            raise FilterError('Player reported an invalid playback position (%r seconds)' % position)
        if position < 0:
            if now - self.started_at >= STARTUP_TIMING_GRACE:
                raise FilterError('Player reported a negative playback position after startup (%r seconds)' % position)
            # Some streams start with a small negative presentation timestamp.
            # Treat this as the opening frame, not a reason to bypass filters.
            position = 0.0
        try:
            duration = number(duration)
        except FilterError:
            raise FilterError('Player reported an invalid movie duration (%r seconds)' % duration)
        if duration == 0:
            # Kodi can announce AV startup before the stream duration is available.
            # Keep enforcing timestamp-based filters; never wait by playing unfiltered.
            if self.duration_ready:
                raise FilterError('Player lost the movie duration during playback')
            if now - self.started_at >= STARTUP_TIMING_GRACE:
                raise FilterError('Movie duration was still unavailable after 5 seconds; try another source')
        else:
            self.duration_ready = True
        if duration > 0 and any(end > duration for ranges in self.timeline.values() for _, end in ranges):
            raise FilterError('Filters extend beyond this video; check the edition and timing')
        target = skip_target(self.timeline, position)
        if self.seek_guard:
            start, end, attempts = self.seek_guard
            # Keep the attempt budget through clock bounce around the endpoint.
            # Reset only after clear forward progress or a rewind before the cut.
            if position >= end + SEEK_CLEARANCE or position < start:
                self.seek_guard = None
        if self.pending:
            deadline, previous_target = self.pending
            if target is None or position >= previous_target:
                self.pending = None
            elif now >= deadline:
                raise FilterError('The player did not complete a filtered seek')
            else:
                return
        if target is not None:
            self._mute(True)
            if self.seek_guard and self.seek_guard[1] == target:
                start, end, attempts = self.seek_guard
                attempts += 1
            else:
                start = next(start for start, end in self.timeline['skip'] if end == target)
                attempts = 1
            if attempts > MAX_SEEK_ATTEMPTS:
                raise FilterError('Repeated seeks landed in the same filtered scene; try another source')
            self.seek_guard = (start, target, attempts)
            # A stream may repeatedly land just before the exact requested time.
            # Retry up to one second farther ahead, without shortening any filter.
            seek_to = target + (attempts - 1) * SEEK_RETRY_STEP
            self.pending = (now + 2, target)
            if duration > 0 and seek_to >= duration:
                self.backend.stop()
            else:
                self.backend.seek(seek_to)
        else:
            self._mute(any(start <= position < end for start, end in self.timeline['mute']))

    def close(self):
        if not self.closed:
            self._mute(False)
            self.closed = True
