# -*- coding: utf-8 -*-
"""Bounded, read-only VideoSkip coverage discovery; never matches stream editions."""
import hashlib
import json
import re
import sqlite3
import time
from threading import Lock

from resources.lib.modules.family_filters import FilterError
from resources.lib.modules.family_filter_timing import episode_number
from resources.lib.modules.family_filter_videoskip import (Exchange, Page, clean, imdb_id,
    parse_title, parse_series, parse_skip, route_id)

MAX_CANDIDATES = 3
_lookup_lock = Lock()


def identity(metadata):
    meta = metadata if isinstance(metadata, dict) else {}
    kind = meta.get('mediatype')
    episode = kind == 'episode' or meta.get('episode') not in (None, '', 'None')
    if kind not in (None, '', 'movie', 'episode') or (kind == 'movie' and episode):
        raise FilterError('Select a movie or exact episode')
    imdb = str(meta.get('imdb') or '')
    if not re.fullmatch(r'tt\d{7,10}', imdb):
        raise FilterError('Movie/show IMDb ID missing')
    query = clean(meta.get('tvshowtitle' if episode else 'title') or '')[:120]
    if not query:
        raise FilterError('Movie/show title missing')
    result = dict(kind='episode' if episode else 'movie', imdb=imdb, query=query)
    if episode:
        result.update(season=episode_number(meta.get('season')), episode=episode_number(meta.get('episode'), 1))
        episode_imdb = meta.get('episode_imdb')
        if episode_imdb and not re.fullmatch(r'tt\d{7,10}', str(episode_imdb)):
            raise FilterError('Invalid episode IMDb ID')
        result['episode_imdb'] = episode_imdb or ''
    return result


def discover(client, subject, cancelled=lambda: False):
    """At most one search, three candidate pages and three exact episode pages."""
    started = time.monotonic()
    def check():
        if cancelled():
            raise FilterError('VideoSkip lookup cancelled')
        if time.monotonic() - started > 25:
            raise FilterError('VideoSkip lookup time budget exceeded')
    def get(path):
        check()
        return client.get(path)
    entries, partial = [], False
    try:
        check()
        results = client.search(subject['query'], subject['kind'])
        partial = len(results) > MAX_CANDIDATES
        for candidate in results[:MAX_CANDIDATES]:
            identifier = candidate['id']
            if subject['kind'] == 'episode':
                body = get('/exchange/series/%s/' % identifier)
                root = Page(body).root
                if len(root.find('h1')) != 1:
                    raise FilterError('VideoSkip series page changed')
                if imdb_id(root) != subject['imdb']:
                    continue
                # Absence is different from conflicting duplicate episode entries.
                matches = [link for link in root.find('a') if route_id(link, 'videos') and
                           re.match(r'S0*%d\s+E0*%d:' % (subject['season'], subject['episode']), link.text())]
                if not matches:
                    continue
                video = parse_series(body, subject['imdb'], subject['season'], subject['episode'])
            else:
                video = identifier
            title = parse_title(get('/exchange/videos/%s/' % video))
            if title['kind'] != subject['kind']:
                raise FilterError('VideoSkip returned a different media type')
            if subject['kind'] == 'movie':
                if title['imdb'] != subject['imdb']:
                    continue
            else:
                if (title['series'], title['season'], title['episode']) != (identifier, subject['season'], subject['episode']):
                    raise FilterError('VideoSkip returned a different episode')
                if subject['episode_imdb'] and subject['episode_imdb'] != title['imdb']:
                    raise FilterError('VideoSkip episode identity conflicts')
            for skip in title['skips']:
                entry = dict(video=video, skip=skip, title=title['title'])
                if entry not in entries:
                    entries.append(entry)
        check()
        state = 'available' if entries else 'unchecked' if partial else 'missing'
    except Exception:
        state, partial = ('available' if entries else 'unavailable'), True
    return dict(state=state, entries=entries, partial=partial)


def availability(cache_path, subject, cancelled=lambda: False):
    """Shared page cache plus result cache, including short-lived lookup failures."""
    key = hashlib.sha256(json.dumps(subject, sort_keys=True).encode()).hexdigest()
    # Only one background discovery runs per interpreter; closing a waiting window
    # cancels its queued lookup. Interactive Exchange requests retain shared pacing.
    while not _lookup_lock.acquire(timeout=0.1):
        if cancelled():
            return dict(state='unavailable', entries=[], partial=True)
    try:
        if cancelled():
            return dict(state='unavailable', entries=[], partial=True)
        now = time.time()
        try:
            with sqlite3.connect(cache_path, timeout=1) as db:
                db.execute('CREATE TABLE IF NOT EXISTS videoskip_status (key TEXT PRIMARY KEY, fetched REAL, result TEXT)')
                row = db.execute('SELECT fetched, result FROM videoskip_status WHERE key=?', (key,)).fetchone()
            if row:
                cached = json.loads(row[1])
                ttl = 300 if cached['state'] in ('unavailable', 'unchecked') or cached['partial'] else 3600
                if 0 <= now - row[0] < ttl:
                    return cached
        except (sqlite3.Error, ValueError, TypeError, KeyError):
            pass
        result = discover(Exchange(cache_path), subject, cancelled)
        if not cancelled():
            try:
                with sqlite3.connect(cache_path, timeout=1) as db:
                    db.execute('INSERT OR REPLACE INTO videoskip_status VALUES (?, ?, ?)', (key, now, json.dumps(result)))
                    db.execute('DELETE FROM videoskip_status WHERE fetched < ?', (now - 86400,))
                    db.execute('DELETE FROM videoskip_status WHERE key IN '
                               '(SELECT key FROM videoskip_status ORDER BY fetched DESC LIMIT -1 OFFSET 256)')
            except sqlite3.Error:
                pass
        return result
    finally:
        _lookup_lock.release()


def details(cache_path, entry):
    # Explicit parent request: fetch metadata only, never the filter download.
    info = parse_skip(Exchange(cache_path).get('/exchange/skip/%s/' % entry['skip']), entry['video'], entry['skip'])
    return '\n'.join([clean(entry['title']), info['author'], 'Reference edition/platform: ' + info['edition'],
        info['description'], 'Filter #' + entry['skip'],
        'Umbrella Family converts blur instructions to full scene skips when their category is selected.',
        'Title/episode availability only. This does not match the selected stream or verify timing/coverage. '
        'Choose VideoSkip during the pre-playback filter review to select and download a filter.'])
