# Umbrella Family

An experimental fork of [Umbrella for Kodi](https://github.com/umbrellaplug/umbrellaplug.github.io)
with optional scene skipping and subtitle-based word silencing. This project is
independent of the official Umbrella maintainers. Original copyright and license
notices are retained in the add-on source directories.

**Development status:** Family Filters is a beta. Earlier builds received limited
FireStick/Kodi 21.1 playback testing; the beta 7/8/9 features still need device
validation. Automated tests do not establish child-safe playback or complete coverage.

**Public distribution:** [Download and install Umbrella Family](https://ccherbst.github.io/umbrella-family-repo/).
The dedicated [download repository](https://github.com/CCHerbst/umbrella-family-repo)
contains packaged releases, update metadata, and a user-facing README rather than
an unpacked application source tree. Beta 10 introduces `plugin.video.umbrellafamily`
with a separate profile and isolated shared properties. Install its Kodi repository
once for future beta updates. This channel currently serves **Kodi 21 Omega only**.
The page includes settings export/import migration instructions for earlier betas.

Development source directories retain `plugin.video.umbrella`; the release builder
rewrites the install identity, settings/property namespace, and manifest for the
public artifact. Do not distribute a raw source-directory ZIP: it still replaces
original Umbrella. Legacy preference backups are accepted by the public package;
account consent and validation rules remain in force. Disable the old beta after
migration and recreate shortcuts pointing to the old identity.

Source directories: `matrix/plugin.video.umbrella` (Kodi 19),
`nexus/plugin.video.umbrella` (Kodi 20), `omega/plugin.video.umbrella` (Kodi 21),
and `piers/plugin.video.umbrella` (Kodi 22). To build a public Kodi 21 distribution
into a new or empty directory:

```sh
python3 scripts/build_family_release.py --version 6.8.01+family.11 --output /tmp/umbrella-family-public-build
```

For subsequent releases, use a strictly increasing beta number with the tested
publisher (requires authenticated `gh` and a Python environment with requests/Pillow):

```sh
python scripts/publish_family_release.py --version 6.8.01+family.11 --publish
```

Omit `--publish` to test and build locally. Publishing preserves old versioned
ZIPs and refuses to overwrite an existing ZIP with different bytes. GitHub Pages
deploys the distribution repository's `main` branch automatically. Verify that
deployment and the hosted checksums before announcing a release. No development
source commits are pushed by the publisher. The matching source ZIP includes
all mirrors, tests, build scripts, and original license notices; rebuilding it
does not require Git history. Test with an adult present before using filtering
with children.

## Fork development: Family Filters beta

This checkout adds opt-in scene filtering and subtitle-based word silencing. The
feature is disabled by default. This is a development beta, not a guarantee that
all inappropriate content will be removed. Kodi startup, seeking and audio
passthrough need testing on the actual device before use with children.

### Using the feature

Beta 11 includes pre-playback subtitle discovery/download,
in-player manual reference timing, and combined CleanStream/VideoSkip availability
above source lists, described below. These features require adult-only device
acceptance testing; automated tests do not establish playback safety.

1. Open **Settings → Playback → Family Filters (beta)** and enable it.
2. Set category thresholds and, optionally, your comma-separated list of words
   and phrases to silence. Match inflections explicitly (for example, add both
   a word and its plural). Matches ignore case and use whole-word boundaries.
3. Start a movie or individual episode through normal title/source selection.
   Choose one source, or set **Preferred filter source** to bypass the chooser
   (never the review). An unavailable preferred provider stops rather than switching:
   - **CleanStream**: online lookup by IMDb movie ID, with a 24-hour local cache.
   - **Import**: choose a local/network `.edl`, MovieContentFilter `.mcf`, or
     VideoSkip `.skp` file obtained for your release.
   - **VideoSkip file**: a dedicated chooser for downloaded `.skp` files.
   - **VideoSkip online exchange**: search by title, select the exact movie/show,
     inspect a filter's author/edition/notes, and confirm its download for review.
     Movies are checked by IMDb; episodes by show IMDb plus exact season/episode.
     No account is required for browsing or downloads. Requests-only entries are
     not playable filters. Cancellation or an identity mismatch blocks playback.
   - **Subtitle silencing**: choose matching `.srt` or full-video `.vtt` text.
     Every cue containing a selected word is silenced in full. Segmented WebVTT
     with `X-TIMESTAMP-MAP` is rejected rather than guessing its timeline.
4. For combined scene filtering and word silencing, enable **Also silence words
   from SRT or WebVTT subtitles**. You will be prompted for subtitles after selecting
   scene filters. Scene and subtitle timing adjustments are independent.
5. **Default scene timing offset** and **Default subtitle timing offset** in
   Family Filters settings are applied automatically. Both default to **0**;
   positive seconds move filters later and negative seconds move them earlier.
   Signed decimals are supported from -3600 to 3600 seconds. Existing installs
   without these settings also use zero. There is no routine offset prompt.
6. Review the selected stream filename, source, edition information and final
   skip/mute intervals before confirming playback. Positive offsets move filters
   later; negative offsets move them earlier. Padding extends both ends. Choose
   **Adjust timing** on the confirmation to override offsets for this playback
   only by default, then review recalculated ranges before selecting **Use filters**.
   These overrides do not change the saved defaults. Different releases may
   still need different offsets; a saved default is not proof of a timing match.

### Pre-playback subtitle discovery (beta 11)

Family word silencing can now find and download a subtitle without browsing for
a local file. It still requires selecting the edition, approving the download,
and reviewing the final filters. This is not embedded-CC extraction, live speech
recognition, or automatic timing verification. The default remains manual import.

1. Set **Settings → Playback → Family Filters → Subtitle source for word
   silencing → Find and download from OpenSubtitles**.
2. Set **Family subtitle language code** to the spoken audio's language (for
   example `en`, `es`, or `pt-br`) and configure your matching-language word list.
3. Supply a separately configured **OpenSubtitles API key for Family downloads**.
   This path does not use the upstream Umbrella application's shared key.
   Enter your existing OpenSubtitles username/password in the **Subtitles**
   settings category; these fields also appear when Family online subtitles are
   selected, so the legacy after-start download toggle need not be enabled.
4. Choose subtitle-only filtering, or enable **Also silence words from SRT or
   WebVTT subtitles** alongside scene filtering. Lookup runs while playback is
   stopped. Choose the matching release from the locally ranked candidates and
   explicitly approve the quota-counted download, then review the filter ranges.

The adapter follows the [OpenSubtitles REST API](https://ai.opensubtitles.com/api-docs).
It searches with a movie IMDb ID, or a show IMDb ID plus exact season/episode
(including season-zero specials), and language. Returned identity is checked
again, including an episode IMDb ID when one is available. The first results
page is bounded to 60 records; there is no automatic pagination or title-only
fallback. Forced/foreign-parts-only captions, provider-flagged machine/AI
translations, multi-file/disc records, and detected identity/filename conflicts
are excluded. These checks cannot establish complete dialogue or timing coverage.
Ranking by filename similarity stays local and is not a confidence rating.

Only title identifiers, episode numbers and language are sent for searching;
stream URLs, headers, signed tokens, filenames and the configured word list are
not uploaded. Login sends the configured account credentials only to the fixed
HTTPS API. Returned API hosts and download destinations are allowlisted, redirects
are bounded, credentials are never forwarded to file-download hosts, responses
are capped at 2 MiB with timeouts/cancellation, and API requests are locally paced.
Account/token errors and rate limits are not automatically retried. Download
links and text are not persisted; another attempt may consume another quota unit.
No subscription, payment, AI transcription, translation, or content upload occurs.

Failures stop preparation unless the adult explicitly chooses manual import.
Cancellation never falls through into playback or manual import. Captions with no
blocked words are not a safety rating; existing empty-filter behavior is retained.
The selected subtitle's filename, release, provider and language appear in final
review, including when combined with scene filters. During any Family session,
the legacy after-start subtitle downloader is suppressed to avoid duplicate
downloads and subtitle-visibility races. Existing embedded captions and manual
Kodi subtitle controls are not replaced by this download feature.

The API key is masked in settings, but Kodi's settings files are not encrypted.
It is excluded from preference-only backups and can be exported only with explicit
OpenSubtitles account consent. Importing preferences without account access cannot
enable this online mode. Never share account-bearing backups or settings files.

Validation uses synthetic provider responses and mocked Kodi UI. A real account/API
key integration test, provider quota/error behavior, and FireStick remote/device
validation are still required before publishing this feature. Beta 10 stays unchanged.

### Parent Audit (beta 8)

In **Settings → Playback → Family Filters (beta)**, enable Family Filters, then
set **Parent audit - next playback only (UNFILTERED)**:

- **Audit current settings:** mark intervals selected by your current category,
  severity, audio-handling and subtitle-word settings.
- **Audit all marked content:** show all usable imported markers, including
  categories disabled by your settings and lower-severity markers. Each banner
  explains whether current settings would skip, mute or allow the interval.

Start a movie or single episode, select its filter as usual, review, and explicitly
choose **Start unfiltered audit**. This plays original video/audio/captions without
automatic skips, muting or caption hiding. Existing user mute/subtitle controls
remain unchanged. Do this without children watching. There is no parent PIN;
audit is a review tool, not access control. The choice resets when the next
supported preparation starts, even if cancelled or rejected, and is not included
in settings backups. Family Filters must be enabled for that preparation.

A persistent amber **PARENT AUDIT - UNFILTERED** header distinguishes audit from
normal filtered playback. A translucent reason banner appears during marked
intervals with category, severity, the supplied description (when available), and
the predicted result. Overlapping reasons are retained; selected skips take
precedence over mutes. A mute prediction includes hiding subtitles while leaving
the picture visible. Long/overlapping reasons are available under **Details**.

Use the remote's directional pad to choose the on-screen buttons and Select to
activate them: **Next marked scene**, **Previous scene**, **Switch audit view**,
**Pause / resume**, **Details**, or **Stop audit**. Next/Previous jumps to three
seconds before the padded interval, never before time zero. Overlapping intervals
form one navigation stop. It does not automatically move on or loop after the
last marker. **Back stops playback**, rather than hiding the audit indicator and
leaving the video running. No global remote keymap is installed. A missing or
closed overlay stops the audit. Changing view changes only the annotations, not
the saved settings or the video/audio. Controls and layout need FireStick testing.

The predictions use a snapshot of settings, offsets and padding taken before
playback; restart after changing filter settings. Ordinary auditing does not save
timing or mark a release as verified. The separate experimental Auto-align action
can save a candidate only after explicit adult approval (see below).
Next-episode autoplay and intro/recap skips remain
disabled, and resume positions are not advanced past filtered scenes. Parent
audit does not disable Kodi/add-on viewing-history or bookmark behavior.

This is **not automated content detection**: it reviews the loaded provider/file
markers, excluding author-disabled VideoSkip entries, and configured-word matches
in subtitles you actually supplied. It does not discover missing scenes, inspect
other providers, load disabled subtitle filters, or prove child-safe playback.
No marker at a particular time is not a safety rating. EDL files generally lack
reasons/severity; the banner says these were not supplied rather than inventing
them. Seek landing and timing accuracy still depend on your stream/device.

### Timing tools and saved adjustments

**Remember timing for this exact stream and filter revision** is off by default.
When enabled, Use filters stores approved scene/subtitle offsets locally. The key
includes the full stream address (including query/headers), title/episode identity,
and filter/subtitle content. Only the hash and offsets are stored, not credentials
or source URLs. Rotated signed URLs cause a safe cache miss; a reused URL is still
not proof the media is unchanged. Review is always required. To reset an entry,
choose **Adjust timing → Forget this saved timing and use defaults**. Disabling
the setting prevents reuse but does not delete previously saved entries.

For VideoSkip files with a reference timestamp, choose **Adjust timing → View
reference and calculate offset from a measured timestamp**. The bounded JPEG/PNG
preview shows the author's landmark. An adult must first measure the matching
moment in their own video separately, then enter seconds or `HH:MM:SS` here. The
pre-playback tool does not launch unfiltered playback. The beta 11 Parent Audit
controls described below also allow measuring the landmark inside the player.
The calculated offset is `your measured time - reference time`. An optional second
known landmark must be at least one minute away and agree within 0.25 seconds;
otherwise a single offset is rejected. This tolerance is an input consistency
check, not a measured guarantee of Kodi playback accuracy. One or two points do
not prove full-film coverage. Global defaults are never overwritten.

**Test frame capture (while a video is playing)** is a read-only diagnostic in
Family Filters settings. It checks whether Kodi returns a nonblank frame; it does
not prove that the frame is video or correctly timestamped. No images are saved
or uploaded, no seeking/muting occurs, and hardware acceleration is not changed.
Experimental automatic reference matching is described below; this diagnostic
does not establish that timestamps or image matches are accurate.

### In-player manual reference timing (beta 11)

Parent Audit now offers a capture-free way to mark a VideoSkip reference landmark.
It works with a reference timestamp plus a description or screenshot; filters
without reference metadata (including current CleanStream filters) cannot use it.
No RenderCapture, Pillow, external app, or server is needed for manual marking.

1. Arm **Parent audit - next playback only** and select a filter with a reference.
   Audit playback is **unfiltered**: do this without children watching.
2. Press Up from the audit buttons to reach the timing controls. **View reference**
   pauses playback and displays the author's landmark; closing it does not resume.
3. **Go to reference** seeks three seconds before the reference plus the current
   scene offset. **Seek -1 second / Seek +1 second** adjust the requested position.
   Use **Pause / resume** to find and pause on the matching landmark. Kodi seeks
   are not frame-accurate; inspect the actual picture, not just the requested time.
4. Wait at least two seconds after a seek, then choose **Mark reference**. The
   paused clock must remain stable. The proposed offset is your paused position
   minus the author's reference time; invalid/out-of-video filter ranges reject it.
5. Playback stops before the save confirmation. Accept to save only for this exact
   stream/filter revision and enable remembered timing, or decline to save nothing.
   Subtitle offsets and global defaults remain unchanged. Restart the same source
   and audit later scenes; one landmark does not verify synchronization or coverage.

This feature is included in beta 11. Automated
tests use mocked Kodi playback; FireStick/Kodi 21.1 device testing is still required.
Audible replacement bleeps remain deferred: Kodi 21.1's global mute also mutes
GUI/SFX sounds, so playing a beep while using the existing silence mechanism is
not a reliable solution. Existing word silencing remains available.

### Experimental automatic reference matching (beta 9)

This is **automatic candidate finding with adult approval**, not unattended or
certified synchronization. In Parent Audit, **Auto-align (experimental)** becomes
available when the selected VideoSkip file contains a reference screenshot.
CleanStream currently supplies no such screenshot, so its filters cannot use
this image-based workflow. Subtitle timing is not automatically aligned.

1. Select **Parent audit - next playback only**, then choose a VideoSkip filter
   online or from a file. Confirm unfiltered adult playback, without children.
2. Choose **Auto-align (experimental)** in the audit overlay (above Stop audit).
   Confirm the bounded seek-and-play scan. It searches ten seconds either side
   of the reference timestamp plus the current scene offset. If the expected
   difference is larger, set an approximate offset before starting the audit.
3. The scan checks decoded video pixels locally, collecting frames for up to
   45 seconds including seek time. It rejects unavailable/black/frozen captures,
   weak or repeated matches, aspect-ratio mismatches, poor time coverage and
   matches at the search boundary. Back/Stop cancels. Audio/subtitle controls and
   hardware acceleration are not changed; the scan may resume a paused video.
4. Playback stops on success or failure. For a usable proposal, compare the
   **reference on the left** with the **candidate frame on the right**. Continue
   to the separate save confirmation, or Back to reject. No automatic save.
5. Accepting saves the proposed scene offset under the exact stream/filter hash
   and enables **Remember timing**. Subtitle timing and global offset defaults
   are untouched. Restart the same source, review the applied offset, and audit
   multiple later scenes before using filters with children. Rotated signed URLs
   cause a cache miss. Re-arm Parent Audit if you want another unfiltered review.

The image decoder uses Kodi's optional bundled `script.module.pil`; missing
decoding/capture support fails with a manual-alignment message. Android hardware
surface rendering can return no usable pixels. The add-on never disables hardware
acceleration to work around this. Reference/candidate images are not uploaded.
The comparison preview is written temporarily in Kodi's temp directory and
removed when the preview closes; scanning frames stay in memory.

Matching thresholds are conservative heuristics, **not a calibrated probability
or an accuracy guarantee**. Kodi capture frames are not supplied with exact
presentation timestamps; sampling/decoder latency can shift a proposal even when
the pictures match. One landmark cannot detect later edits, ads or frame-rate
drift. Device validation on FireStick/Kodi 21.1 remains required. If the image is
ambiguous or capture fails, use manual landmarks; no guessed offset is saved.

Audio-only scene filters can silence or skip according to the setting. Explicit
SRT word filters always silence, independent of category thresholds. During
silenced intervals, subtitles are hidden too; mute/subtitle state is restored on
exit. Subtitle filtering operates on whole cues, not individual word timings.
Missing captions, alternate audio languages, censored captions, spelling variants
and mismatched timing can all miss spoken words. Live/embedded CC extraction and
audible replacement bleeps are not included. Pre-playback subtitle downloading is
included in beta 11 as described above.

### CleanStream / VideoSkip status above source lists (expanded in beta 11)

Normal and uncached source windows check both providers in independent background
workers; sources remain selectable. CleanStream remains movie-only. VideoSkip
searches the movie/show title, then verifies movie IMDb or show IMDb plus exact
season/episode; an explicit episode IMDb must also agree. No stream address,
release filename, credentials or subtitle text is sent to VideoSkip. Season-zero
specials require explicit episode numbers; a show-only match is never coverage.

The scrolling banner distinguishes **filters found**, **none found in search**,
**lookup failed**, and **not confirmed — search limit reached**. If a bounded
search finds some filters but cannot finish, it says **partial search**. No result
certifies the highlighted stream's edition, timing, completeness or suitability.
Every banner says **timing unverified**, and says **filtering off** when applicable.
There are no per-stream compatibility badges or automatic filter selections.

On the FireStick, open the source item's context menu (Menu button), then select
**Family filter availability / VideoSkip details**. Read the provider summary,
choose an available VideoSkip filter, and inspect its author, reference edition
and notes. Inspection retrieves metadata only; it neither downloads/applies a
filter nor starts playback. Select/download through the existing pre-playback
VideoSkip browser and review timing before use. No results yet? Close the dialog,
allow the background check to finish, and reopen it.

Each VideoSkip check reads at most one search page, three candidate pages and
(for shows) three exact-episode pages. No pagination/crawling or automatic retry.
A 25-second elapsed budget prevents starting more requests; an in-flight request
can finish later under the existing network timeout/body limits. Closing a source
window cancels queued/further requests and discards UI updates. One background
discovery runs per Python interpreter; interactive browsing shares request pacing.
Pages and complete results are cached locally for one hour; incomplete/error
results for five minutes (page caching still applies). Result entries are bounded
to 256 and old entries expire. Cached matches still require adult timing review.

**Show CleanStream / VideoSkip availability above sources** controls both checks
and the inspection menu. Disable it to prevent source-window provider lookups;
pre-playback browsing remains available. Disabling only CleanStream does not
disable VideoSkip. This expansion is included in beta 11; it requires FireStick
UI/network testing before release.

**Show CleanStream availability above sources** is enabled by default in Family
Filters settings, independently of enabling playback filtering. Turn it off to
avoid browsing-time lookups. Disabling the CleanStream adapter also prevents
lookups. Requests send the movie IMDb ID to the configured server, not source
URLs. Successful results are cached for 24 hours, missing coverage for 10 minutes,
and lookup failures for one minute. Cached filter data is reused during playback,
but selection and review are still required. Closing a source window does not
wait for its request; late results cannot update a different title's window.

### Supported sources and limits

- [CleanStream](https://github.com/ameen-roayan/stremio-cleanstream#api-endpoints)
  is the first online adapter. It sends the movie IMDb ID to the configured HTTPS
  server. A response is not proof of complete coverage or an edition match;
  unverified segment counts are shown. Network failures never silently start an
  unfiltered movie. Expired cache entries are not used as an offline fallback.
- [VideoSkip Exchange](https://videoskip.herokuapp.com/exchange/) supports manual
  imports and on-demand online search/download in beta 9. The project owner reports
  author approval for this integration. It uses the existing public HTML pages,
  not a claimed stable JSON API. Page structure changes fail closed. Titles and
  episode identities are verified before downloading; source URLs are never sent.
  Search text and selected exchange IDs are sent to VideoSkip. Requests stay on
  the fixed HTTPS origin without redirects, have time/size limits, and are spaced
  by at least one second within an add-on process. There is no background crawl,
  bulk download, login, upload or automatic retry. HTTP 429/errors surface to the
  user. Pages cache locally for one hour and downloaded files for 24 hours;
  expired responses are not an offline fallback. Author/platform/coverage notes
  remain visible, and filter review is still required. Numeric skip-file IDs
  identify choices; open one to inspect its author and edition before download.
  The importer preserves reference images/timestamps and source offsets. It does
  **not** automatically apply `local`, Disney+, or other service offsets to an
  arbitrary Kodi stream. This changes the earlier beta's automatic `local` offset
  behavior: recheck old imports. Video-only, blur and fast-forward edits become full skips;
  author-disabled `//` cues remain disabled. VideoSkip's combined sex/nudity
  labels map to the combined category: the more inclusive enabled Sexual content
  or Nudity threshold is used. Review discloses this; check the final ranges.
- [MovieContentFilter](https://github.com/delight-im/MovieContentFilter) 1.0.0 and
  1.1.0 imports support categories and channels. Video-only edits become skips.
  Recognized subcategories map to the matching setting; other categories remain
  Other/unclassified. Its online service is not connected.
- [Kodi/MPlayer EDL](https://kodi.wiki/view/Edit_decision_list) actions 0 and 3
  skip on every visit, action 1 mutes, and action 2 is a scene marker only. The
  file chooser accepts timestamps in seconds or timecodes. Convert frame-based
  EDLs to seconds first; the importer cannot infer the source frame rate.
- Commercial VidAngel/ClearPlay catalogs are not connected.

This beta supports normal HTTP(S) **movie and single-episode** playback. Raw cloud
playback, direct playlist playback and local/native-EDL playback are blocked
while the feature is enabled. Playback elsewhere in Kodi is outside its scope;
these settings are not a PIN-protected parental lock. Native local EDL cuts
change the player timeline, so they must not be combined with this controller.

Episodes require a valid season/episode number and explicit adult confirmation
that each imported filter/subtitle belongs to that exact episode. Contradictory
MCF metadata or `SxxExx` filenames are rejected. An IMDb episode ID in a file
must match an explicit `episode_imdb` in playback metadata; a show ID is never
accepted as its substitute. Missing identity is not inferred from edit timings.
Season-zero specials are accepted only with explicit episode selection. Combined
episodes/alternate numbering cannot be automatically resolved. Next-episode
autoplay is disabled and stale playlists are cleared for filtered sessions.
CleanStream remains movie-only. Source lists and metadata alone cannot certify
that any downloaded filter has complete coverage.

### Remaining release gates

- Record any specific maintainer API/rate-limit requirements supplied with the
  project owner's reported approval. Public-page browsing is connected with
  conservative local caching/pacing; no official JSON API contract is assumed.
- Validate capture, UI navigation, seeking, startup, pause/resume, episode
  transitions and audio passthrough on FireStick/Kodi 21.1 before broad use.
- Validate experimental visual proposals against known offsets/editions on real
  devices. Fully unattended sync, audio alignment, embedded subtitle extraction,
  live speech recognition and audible bleeps are not included. Do not treat a
  proposed or saved offset as verified synchronization.
- Validate the beta 11 subtitle downloader with configured Family API access
  and an OpenSubtitles account before broad use; credentialed live testing remains outstanding.
- Keep the distinct-ID release builder and update repository verified for every
  release. Raw development-directory installs still replace official Umbrella.

Filter selection/review is repeated for each playback, including cached online
data; approval is not remembered across releases. An IMDb match or runtime
comparison cannot establish that edits line up. The controller stops playback
if a range exceeds the reported duration, the stream changes, or a seek fails
to leave its filtered range within two seconds. If the player briefly reports
leaving a cut but then lands back inside it, retries aim 0.5 and then 1 second
past the original endpoint. A fourth attempt stops playback instead of looping.
This budget resets after progress at least two seconds beyond the cut or a
rewind before its start. Retries may remove up to one extra second of content;
filters remain active, including any following cut. At startup, a zero/unknown movie
duration is tolerated for up to five seconds while timestamp-based skip/mute
filters continue to run. During that same startup window, player positions from
-1 to 0 seconds are treated as zero so opening filters still apply. More negative
positions, negative positions after the startup window, other invalid timing,
a duration that remains unknown, or loss of duration after it
was available stops playback. Subtitle word lists are stored in add-on settings;
online responses are cached in the add-on profile's `family_filters.db`.

### Development and validation

Run `PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -v`.
Install Pillow in an isolated test environment to run pixel-level alignment
tests (otherwise these explicitly skip); requests is needed for optional live
exchange smoke checks. No test dependency needs to be installed globally.
Tests exercise parsers, providers, playback state, subtitle matching, Kodi
adapter behavior and parity across Matrix, Nexus, Omega and Piers. They use
synthetic timelines and mocked Kodi interfaces; they do not prove device-level
audio/video timing. The implementation polls the active playback session every
50 ms, with an additional seek check for resume targets.

Before a release, test on Kodi with a synthetic movie and known scene markers:
startup cuts, single-word captions, rewind/resume, pause/buffering, failed seeks,
stop/EOF, user mute state, subtitles and audio passthrough. Verify that provider
failure and cancelled review prevent playback. Check normal playback with the
feature disabled. Real-device testing and remaining source integrations are
outstanding. The source add-on retains the upstream ID; use the release builder
for distribution so the separate identity and namespaces are applied. Editing
development source does not publish updates: run the tested publisher explicitly.

## Upstream Umbrella documentation

The following original documentation describes official Umbrella. Its repository
URL installs the official add-on, not the Family Filters development code above.

Welcome to the umbrellaplug.github.io

Compatible with Kodi 19, 20, 21, and 22.

## Current Versions:
Umbrella - 6.8.01
Umbrella Repo - 2.2.6

## Installation Instructions:
From Kodi:
System > File Manager > Select Add Source

For "Enter the paths or browse for the media locations" select "None" and input:

**https://umbrellaplug.github.io**

Then Select Done. For "Enter a name for this media source" input "Umbrella" or whatever you would like to name the source.
Click Ok.

From the Kodi Homescreen select "Add-ons".
At the top on the left hand side select the box icon under "Add-ons" (Add-on Browser).

Install the Umbrella repository by clicking on Install from Zip File then "Umbrella" then repository.umbrella-x-x-x.zip and waiting for the repository installed icon to appear in the top right corner.

Select "Install From Repository" then Umbrella Repo then Video Add-ons then Umbrella. Click on Install and wait for the Add-on Enabled Notification.

## Setup Instructions

From the main menu, navigate to Tools > Settings > Trakt
Follow the onscreen instructions and authorize Trakt.

Next add any debrid services you use and follow the on-screen instructions.
Currently Supported Debrid Providers:
- All Debrid
- Real Debrid
- Premiumize
- TorBox
- OffCloud

Currently Supported Other Providers:
- Easynews
- Plex
- Google Drive

**The plugin will not work without at least 1 of these types of accounts**

## Issues
Please do not mention any other addons in issues.

## Logs
Information about what how to set up logging and what is needed can be found here:
https://github.com/umbrellaplug/umbrellaplug.github.io/discussions/649

## FAQ

**Q:** After setting up, I'm getting "No Sources Found"

**A:** Umbrella only searches your cloud from Providers you have entered. For additional sources, external providers can be installed. Umbrella does not offer support for any external providers.


**Q:** Do you take feature requests?

**A:** Some yes. Open an issue and use the feature request template.


[Setup Instructions](https://github.com/umbrellaplug/umbrellaplug.github.io/wiki#setup-instructions)
