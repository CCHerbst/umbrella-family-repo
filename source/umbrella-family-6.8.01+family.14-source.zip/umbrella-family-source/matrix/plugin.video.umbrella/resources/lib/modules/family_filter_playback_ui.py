# -*- coding: utf-8 -*-
"""Playback UI on its own Kodi callback thread, independent of filtering ticks."""
from threading import Event, Lock, Thread
import xbmc
import xbmcgui
from resources.lib.modules import control


class OverlayHost:
    def __init__(self, window_type, filename, command):
        self.ready, self.window_id, self.failed = False, None, False
        self.closed = Event()
        self.lock = Lock()
        self.properties = {}
        self.thread = Thread(target=self._run, args=(window_type, filename, command))
        self.thread.daemon = True
        self.thread.start()

    def setProperty(self, key, value):
        with self.lock:
            self.properties[key] = value

    def close(self):
        # Never wait for a UI callback while holding the playback session lock.
        self.closed.set()

    def _run(self, window_type, filename, command):
        window = None
        try:
            if self.closed.is_set():
                return
            window = window_type(filename, control.addonPath(control.addonId()), 'Default', '1080i')
            window.command, window.ready = command, False
            if self.closed.is_set():
                return
            window.show()
            while not self.closed.is_set() and not control.monitor.abortRequested():
                with self.lock:
                    properties, self.properties = self.properties, {}
                for key, value in properties.items():
                    window.setProperty(key, value)
                # xbmc.sleep dispatches Kodi callbacks on the window's creating
                # thread. threading.Event.wait alone does not do that.
                xbmc.sleep(50)
                if window.ready:
                    self.window_id, self.ready = window.window_id, True
                    if not xbmc.getCondVisibility('Window.IsVisible(%d)' % self.window_id):
                        break
        except Exception:
            self.failed = True
        finally:
            self.closed.set()
            if window is not None:
                try:
                    window.close()
                except Exception:
                    pass


class PlaybackOverlay(xbmcgui.WindowXMLDialog):
    def onInit(self):
        self.window_id = xbmcgui.getCurrentWindowDialogId()
        self.ready = True
        self.setFocusId(100)

    def onClick(self, control_id):
        action = {100: 'pause', 101: 'back', 102: 'forward', 103: 'next_filter',
                  104: 'details', 105: 'native', 106: 'dismiss', 107: 'stop', 108: 'toggle_filters', 109: 'audit'}.get(control_id)
        if action:
            self.command(action)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (9, 10, 92, 216):
            self.command('dismiss')
        elif action_id == 13:
            self.command('stop')
        elif action_id in (12, 229):
            self.command('pause')
        elif action_id == 79:
            self.command('play')
        elif action_id in (77, 20):
            self.command('forward')
        elif action_id in (78, 21):
            self.command('back')


def create_controls(command):
    return OverlayHost(PlaybackOverlay, 'family_playback.xml', command)
