# -*- coding: utf-8 -*-
"""Explicitly unfiltered parent review overlay; never changes mute/subtitle state."""
import xbmcgui
from resources.lib.modules import control


class AuditOverlay(xbmcgui.WindowXMLDialog):
    def onInit(self):
        self.window_id = xbmcgui.getCurrentWindowDialogId()
        self.ready = True
        self.setFocusId(100)

    def onClick(self, control_id):
        command = {100: 'next', 101: 'previous', 102: 'view', 103: 'pause', 104: 'details', 105: 'stop', 106: 'align'}.get(control_id)
        if command:
            self.command(command)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (9, 10, 13, 92, 216):
            self.command('stop')
        elif action_id in (12, 79, 229):
            self.command('pause')


def create_overlay(command):
    window = AuditOverlay('family_audit.xml', control.addonPath(), 'Default', '1080i')
    window.command = command
    window.ready = False
    window.show()
    return window
