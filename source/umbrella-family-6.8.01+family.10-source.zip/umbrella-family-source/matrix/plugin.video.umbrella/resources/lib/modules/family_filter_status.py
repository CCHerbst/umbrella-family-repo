# -*- coding: utf-8 -*-
"""Non-blocking, per-window CleanStream availability for source lists."""
import os
import re
from threading import RLock, Thread

import xbmcvfs
from resources.lib.modules import control
from resources.lib.modules.family_filter_provider import availability

PROPERTY = 'umbrella.cleanstream.status'
MESSAGES = {
    'available': 'CleanStream filters available - timing unverified',
    'missing': 'No CleanStream filters found',
    'unavailable': 'CleanStream unavailable - lookup failed',
}


class SourceStatus:
    def __init__(self, window, metadata):
        self.window = window
        self.metadata = dict(metadata) if isinstance(metadata, dict) else {}
        self.lock = RLock()
        self.closed = False
        self.started = False
        self.thread = None
        self.filtering = control.setting('family.enabled') == 'true'

    def _publish(self, text):
        with self.lock:
            if not self.closed:
                try:
                    self.window.setProperty(PROPERTY, text)
                except Exception:
                    pass  # A closed UI must never interrupt source selection.

    def start(self):
        with self.lock:
            if self.started or self.closed:
                return
            self.started = True
            if control.setting('family.show_status') == 'false':
                self._publish('')
                return
            media_type = self.metadata.get('mediatype')
            is_episode = self.metadata.get('episode') not in (None, '', 'None')
            if media_type in ('episode', 'tvshow', 'season') or is_episode:
                self._publish('Episode: exact-episode import or VideoSkip online search | CleanStream: unsupported')
                return
            if media_type not in (None, '', 'movie'):
                self._publish('CleanStream: media type not supported')
                return
            if control.setting('family.cleanstream') == 'false':
                self._publish('CleanStream lookup disabled')
                return
            imdb = str(self.metadata.get('imdb') or '')
            if not re.fullmatch(r'tt\d{7,10}', imdb):
                self._publish('CleanStream: no movie IMDb ID available')
                return
            self._publish('Checking CleanStream availability...')
            self.thread = Thread(target=self._lookup, args=(imdb,))
            self.thread.daemon = True
            self.thread.start()

    def _lookup(self, imdb):
        try:
            xbmcvfs.mkdirs(control.dataPath)
            state = availability(control.setting('family.server') or 'https://cleanstream.elfhosted.com',
                                 imdb, os.path.join(control.dataPath, 'family_filters.db'))
            text = MESSAGES.get(state, MESSAGES['unavailable'])
        except Exception:
            text = MESSAGES['unavailable']
        if not self.filtering:
            text += ' (filtering off)'
        self._publish(text + ' | VideoSkip: online search / file import (not checked)')

    def close(self):
        with self.lock:
            self.closed = True
        # Do not hold up window closing for a network request. Late results are
        # cached but cannot update this window or a subsequently opened title.
